# Atlas 0.6.0-alpha — design refresh

## Objectif
Moderniser l'interface et remplacer le brouillard uniforme par un brouillard gris texturé, opaque, qui masque complètement les rues non explorées.

## Modifications principales
- Nouvelle palette : ardoise / gris clair / sable.
- Boutons plus arrondis, hauteur minimale augmentée, ripple plus discret.
- Cartes rehaussées avec légère bordure et coins plus larges.
- Navigation inférieure éclaircie et onglet actif mieux mis en évidence.
- Accent harmonisé dans les écrans Explorer, Monde et overlays.
- FogOverlay réécrit avec texture répétée et variations visuelles.

## À tester sur téléphone
1. Lisibilité générale en plein soleil et en intérieur.
2. Contraste des boutons actifs / inactifs.
3. Perception du brouillard gris à différents zooms.
4. Performance du rendu du fog sur trajets longs.
5. Visibilité du texte d'état GPS au-dessus du fond de carte.

## Prochaine étape recommandée
Faire un second passage ergonomique : hiérarchie de l'écran Explorer, fiches de sortie plus visuelles, et onboarding plus propre.
