# Atlas 0.7.1-alpha — Carnet et sorties anciennes

- Une vraie carte OpenStreetMap/OpenTopoMap s'affiche dans la fiche d'une sortie, avec la trace superposée et le brouillard respecté ; bouton pour ouvrir la carte interactive plein écran. L'aperçu sommaire de la liste reste léger pour ne pas ouvrir des dizaines de cartes en même temps.
- Depuis la fiche d'une **sortie terminée** : **Supprimer cette sortie** puis confirmation. Suppression transactionnelle des points, fiche, statistiques de la sortie, estimation de terrain et références d'import. Les autres sorties sont conservées.
- Royaume : camps associés à une sortie supprimée relocalisés sur un autre point encore enregistré dans la même case ou retirés si la case devient vide. L'ancienne sortie ne contribue plus à la surface dévoilée ni à la progression.
- Les routes terminées ne réapparaissent pas sur la carte principale Explorer : elles restent visibles seulement depuis Carnet.
- Langues FR/EN/AR/ES enrichies pour les nouveaux boutons et avertissements.
- VersionCode 12, signature de développement inchangée, base SQLite inchangée. Sauvegarder les explorations avant installation et suppression.
- Compilation APK via GitHub Actions prévue pour téléphone Android ; les écrans et comportements doivent encore être testés sur un vrai appareil.

# Atlas 0.7.0-alpha — carte et royaumes

- Nouvelle barre de carte compacte, détails dépliables au toucher ou par glissement sur son en-tête. Départ/activité au repos, distance/durée/pause pendant la sortie. Vecteurs pour localisation, suivi, couches et plein écran.
- Suivi GPS explicite ; un déplacement manuel le suspend. Recentrage ponctuel indépendant. Choix des positions fondé sur âge et précision ; ancien point grisé après 5 secondes, supprimé après 10 secondes. Filtre d’enregistrement conservé à 15 m / 5 s, trois mesures initiales. Reprise de positions récentes du téléphone et notification périodique.
- Palette blanc cassé, bleu profond et océan. Animation dorée brève sur un nouveau secteur de 30 m ; aucun effet ne dévoile le terrain hors de la bande. Cache du brouillard corrigé pour les changements de décalage de la carte.
- Royaume : nom/couleur/emblème ; provinces de jeu d’environ 1 km² avec surfaces estimées réellement révélées. Vue en tuiles, liste et accès à la carte réelle. Camps placés sur des points visités, liste des sorties associées, tour à 5 % actifs et 2 sorties, citadelle à 15 % et 5 sorties. Anciens bâtiments conservés. Trois expéditions permanentes, sans expiration.
- La voiture dévoile la carte et compte dans la surface totale. Elle ne compte pas pour les seuils d’évolution et expéditions actives. Les imports GPX selon leur activité sont inclus.
- Recherche Alger : le résultat ville est un point, la wilaya une relation MultiPolygon (réponse vérifiée le 20 octobre 2026). Recherche de secours sans filtre strict, type administratif clairement affiché et sélection explicite. Les résultats vides ne sont plus mis en cache ; anciens caches ignorés par une nouvelle clé.
- Sauvegardes : validation et restauration de la couleur, de l’emblème et des coordonnées/trajet du camp ; anciens fichiers conservés compatibles.
- Langues FR/EN/AR/ES maintenues pour les nouveaux écrans.

Validation : compilation Android et signature, 23 scénarios GPS/recherche Alger/royaume, 15 scénarios géométriques, aller-retour sauvegarde avec nouveaux attributs, fichiers invalides et rollback. Les tests hôtes ne remplacent pas un téléphone : rendu, ergonomie tactile, suivi réel écran éteint et autonomie restent à vérifier sur Android. Aucun pourcentage de ville n’est substitué silencieusement par celui d’une wilaya.

Identifiant fr.amine.atlas ; versionCode 11 ; même clé de développement. Installer par-dessus pour conserver les données.

# Atlas 0.6.2-alpha

- Choix de langue dans Réglages → Langue : français, anglais, arabe, espagnol. Préférence persistante ; orientation RTL en arabe. Les identifiants stockés des activités et des régions restent inchangés. Noms de lieux et noms de royaumes personnalisés conservés.
- Bouton ⛶ en haut de la carte : plein écran immersif, masquant en-tête, panneau de départ/activité et barre de navigation. Bouton ↙ ou Retour pour quitter. Le suivi continue pendant le plein écran.
- Carte principale : ligne de la sortie active uniquement. Finir une sortie retire sa ligne, sans supprimer les points, le carnet, le GPX ou les zones dévoilées.
- Palette bleu océan, surfaces claires, actions principales à texte blanc. Brouillard gris opaque et rayon de révélation de 30 m conservés.
- versionCode 10 ; même identifiant et certificat de développement.

Vérification : compilation, ressources osmdroid, signature et contenu du catalogue des quatre langues. Aucun test sur téléphone ou émulateur dans cet environnement. Les erreurs techniques remontées par les services externes ou certains moteurs internes peuvent conserver leur texte d’origine. Les toponymes cartographiques restent ceux du fournisseur de carte.

# 0.6.1-alpha
- Palette turquoise vive, navigation active menthe et surfaces claires.
- Panneau de sortie compact par défaut, accès direct à Ma position.
- Brouillard gris nuageux procédural, opaque hors des trajets.
- Révélation de 30 m de chaque côté, surfaces recalculées aussi pour les anciens parcours.
- Recentrage au milieu de la portion visible de la carte, correction des positions périmées, affinage GPS pendant 30 secondes maximum ; déplacement manuel de la carte annule le recentrage.
- Même identifiant et signature Android, versionCode 9.

## 0.6.0-alpha

- Refonte visuelle de l'interface : palette plus moderne gris ardoise / sable, boutons plus doux, cartes rehaussées et navigation clarifiée.
- Brouillard retravaillé : texture grise opaque avec variations minérales, sans transparence sur les rues tant qu'elles ne sont pas révélées.
- Accent et composants harmonisés sur les écrans Explorer, Monde et Réglages.

## 0.5.0-alpha

- Monde : surface dévoilée estimée avec cellules d’environ 4 m, calcul d’aire sphérique et déduplication ; pourcentage de la surface totale terrestre, océans inclus.
- Frontières choisies par recherche manuelle ville/région/pays, géométries Nominatim/OSM conservées localement ; calcul par centres de cellules, trous et antiméridien pris en compte.
- Import GPX de traces et routes, conservation des segments/altitudes/heures disponibles, refus des doublons sémantiques, confirmation et validation XML. Coupures >20 km ou >15 min non reliées.
- Altitude du terrain sur demande explicite : échantillonnage à 30 m, Open-Meteo/Copernicus, D+/D− et profil par distance ; GPS brut conservé. Limite 5 000 échantillons, environ 150 km.
- Téléchargement de cinq secteurs vectoriels simplifiés d’environ 2 × 2 km via Overpass, activation hors ligne, suppression individuelle. Pas de relief ni de noms de rues dans ces secteurs. Hors secteur : fond vide.
- Royaume personnel nommé, territoires de jeu d’environ 250 m, ressources obtenues par surface inédite, camps/tours/citadelles persistants et symboles sur les traces. Bâtiments décoratifs.
- Base SQLite v3, nouvelle table extras ; sauvegarde v2 incluant frontières, imports, terrain, nom et bâtiments. Anciennes sauvegardes v1 acceptées. Secteurs hors ligne exclus de la sauvegarde.
- Calcul limité à quatre millions de cellules pour éviter un épuisement mémoire. Aucun pourcentage présenté comme mesure cadastrale ou taux de rues parcourues.

## 0.4.0-alpha

- Carte en plein écran, panneau blanc flottant, commandes accessibles et compteurs réductibles.
- Choix d’activité dans un panneau dédié ; dernier mode et fond de carte mémorisés.
- Guide de démarrage, également accessible depuis les réglages.
- Carnet avec aperçu du tracé réel, fiches détaillées, profil GPS disponible et export GPX.
- Réglages par sections avec explications repliables.
- Sauvegarde JSON des sorties et points ; restauration transactionnelle après confirmation, fichiers invalides refusés.
- Sauvegarde et restauration refusées tant qu’une sortie est active ; données en clair, pas de tuiles ni préférences exportées.
- Cache du masque de brouillard pour une vue inchangée ; chargement des points seulement lorsque leur nombre change.
- Compilation, ressources cartographiques, signature et tests locaux de sauvegarde contrôlés. Rendu et fonctionnement Android à tester sur appareil.

## 0.3.0-alpha

- Interface nuit/ambre, icônes vectorielles des quatre modes et navigation, cartes de métriques.
- Position et rayon d’incertitude affichés sans dévoiler le terrain.
- GPS demandé à 1 Hz, rayon annoncé <=15 m et âge <=5 s. Trois mesures initiales avant enregistrement.
- Filtrage de dérive à l’arrêt lorsque la vitesse et son incertitude le permettent ; seuil de déplacement 2,5–6 m.
- Rupture de segment après perte de signal, sans interpolation des zones manquantes.
- Limite : amélioration du filtrage, aucun gain de précision matérielle garanti. Tests sur téléphone et comparaison terrain encore nécessaires.

## 0.2.2-alpha

- Mode Voiture : sélection, carnet, brouillard et reprise de sortie.
- Filtre de sauts GPS adapté (70 m/s maximum, seuil technique et non limite routière).
- Vitesse moyenne en km/h pour les trajets voiture.
- Contrôle des ressources de carte conservé.

# Atlas 0.2.1 — correctif bloquant

L’assemblage manuel 0.1/0.2 générait les classes R sous org.osmdroid au lieu de org.osmdroid.library. Certaines branches de rendu (notamment les info-bulles de Polyline) référencent org.osmdroid.library.R : la présence d’un parcours pouvait déclencher un NoClassDefFoundError, puis bloquer les réouvertures.

Correction : génération dans le namespace déclaré par l’AAR. Contrôle automatique de toutes les classes de ressources référencées par la bibliothèque. Le contrôle échoue sur l’archive 0.2 et réussit sur la 0.2.1 (drawable, layout, string). Build propre sans résidus, APK signé et vérifié.

Ajout : diagnostic local d’exception et écran de secours au redémarrage, accès au carnet sans carte et export du diagnostic au choix de l’utilisateur. Aucun envoi automatique. Un arrêt forcé système ou un crash natif n’est pas nécessairement capturé par ce mécanisme.

Données conservées : versionCode 3, même application, même clé de signature, schéma SQLite 2 inchangé. Installer par-dessus, sans désinstaller.

Pas de validation sur le téléphone utilisateur. La correction élimine cette erreur démontrée ; elle ne garantit pas l’absence de tout autre problème.
