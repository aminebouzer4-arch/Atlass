# Expedition 0.8 — modifications techniques

## Base
Projet Atlas 0.7.1 Carnet : suivi GPS, SQLite, synchronisation des zones révélées, royaumes, langues, archivage et GPX inchangés.

## Design appliqué
- `Expedition.java` : palette de couleurs centralisée et arrière-plans arrondis avec dégradé.
- `MainActivity.java` : navigation sombre, panneaux cartographiques réorganisés, boutons et fiches plus compacts, réglages nuit.
- `FeaturesActivity.java` : harmonie nuit pour Progression, Royaume, Hors ligne.
- `TripMaps.java`, `NightMapOverlay.java` : assombrissement du fond de carte sur les zones révélées.
- `SmokeTexture.java` : brume gris ardoise opaque avec grain déterministe. **Ne jamais rendre transparent le brouillard hors des zones révélées**.
- `RoutePreview.java`, `KingdomMapView.java`, `TerrainProfile.java`, `TripMapActivity.java` : cartes et aperçus alignés visuellement.
- `styles.xml` : thème Android sombre et composants de dialogue harmonisés.

## Limites
- Tests hôtes de logique sans SDK Android, pas de build ni de validation tactile sur téléphone.
- Le passage à des tuiles vectorielles sombres et le calibrage de la lisibilité du relief restent à faire.
- Les nouveaux textes de la direction artistique ne sont pas tous présents dans les dictionnaires localisés ; les nouvelles libellés apparaîtront en français selon le mécanisme de repli existant.
