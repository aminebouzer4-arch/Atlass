osmdroid 6.1.20 — Apache License 2.0. https://github.com/osmdroid/osmdroid
Map data © OpenStreetMap contributors. https://www.openstreetmap.org/copyright
Map tiles: https://operations.osmfoundation.org/policies/tiles/
Gradle Wrapper: Gradle Inc., Apache License 2.0. https://gradle.org/

OpenTopoMap style © OpenTopoMap, CC-BY-SA ; données © OpenStreetMap contributors et SRTM. https://opentopomap.org/about


## Services ajoutés en 0.5
- Frontières : OpenStreetMap contributors (ODbL), recherche Nominatim. Recherche manuelle, requêtes mises en cache, au moins 1,1 s entre requêtes. https://operations.osmfoundation.org/policies/nominatim/
- Secteurs vectoriels hors ligne : données OSM (ODbL) via Overpass. Téléchargement explicite limité à environ 2 × 2 km, cinq secteurs. Aucun téléchargement massif de tuiles OSM/Topo. https://dev.overpass-api.de/overpass-doc/en/preface/commons.html
- Altitudes : Open-Meteo, Copernicus DEM GLO-90. Attribution dans les fiches. API gratuite réservée ici à l’utilisation personnelle non commerciale ; une diffusion commerciale nécessite de revoir le fournisseur et ses conditions. https://open-meteo.com/en/docs/elevation-api
- Source des données de carte hors ligne : https://www.openstreetmap.org/copyright . Les fichiers téléchargés contiennent l’attribution.
