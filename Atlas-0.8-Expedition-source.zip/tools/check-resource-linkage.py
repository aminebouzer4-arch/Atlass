"""Fail a manual build if an AAR's referenced R class was not generated."""
import re,sys
from zipfile import ZipFile
with ZipFile(sys.argv[1]) as dependency, ZipFile(sys.argv[2]) as app:
    refs=set()
    for n in dependency.namelist():
        if n.endswith('.class'):
            refs.update(x.decode()+'.class' for x in re.findall(rb'org/osmdroid/library/R\$[A-Za-z_]+',dependency.read(n)))
    missing=refs-set(app.namelist())
    if missing:raise SystemExit('Missing resource classes: '+', '.join(sorted(missing)))
    print(f'Resource linkage OK: {len(refs)} required R classes present')
