#!/usr/bin/env bash
# Alternate reproducible build when Gradle dependency resolution is unavailable.
# Requires JDK 17, Android SDK 35/build-tools 35 and unpacked osmdroid-android 6.1.20 AAR.
set -euo pipefail
: "${ANDROID_HOME:?Set ANDROID_HOME}"
: "${JAVA_HOME:?Set JAVA_HOME}"
: "${OSMDROID_AAR_DIR:?Set OSMDROID_AAR_DIR to unpacked osmdroid AAR}"
ROOT=$(cd "$(dirname "$0")/.." && pwd)
BUILD="$ROOT/manual-build"
rm -rf "$BUILD"
mkdir -p "$BUILD/gen" "$BUILD/classes" "$BUILD/dex"
BT="$ANDROID_HOME/build-tools/35.0.0"
ANDROID_JAR="$ANDROID_HOME/platforms/android-35/android.jar"
python3 - "$ROOT" "$BUILD" <<'PY'
from pathlib import Path
import sys
root,build=map(Path,sys.argv[1:])
s=(root/'app/src/main/AndroidManifest.xml').read_text().replace('<manifest xmlns:android=', '<manifest package="fr.amine.atlas" android:versionCode="13" android:versionName="0.8.0-expedition-alpha" xmlns:android=')
s=s.replace('<application ', '<uses-sdk android:minSdkVersion="26" android:targetSdkVersion="34"/><application android:debuggable="true" ')
(build/'AndroidManifest.xml').write_text(s)
PY
"$BT/aapt2" compile --dir "$ROOT/app/src/main/res" -o "$BUILD/app-res.zip"
"$BT/aapt2" compile --dir "$OSMDROID_AAR_DIR/res" -o "$BUILD/osm-res.zip"
# The resource namespace is org.osmdroid.library, NOT org.osmdroid.
"$BT/aapt2" link -o "$BUILD/base.apk" --manifest "$BUILD/AndroidManifest.xml" -I "$ANDROID_JAR" --java "$BUILD/gen" --extra-packages org.osmdroid.library -A "$ROOT/app/src/main/assets" --auto-add-overlay "$BUILD/osm-res.zip" "$BUILD/app-res.zip"
"$JAVA_HOME/bin/javac" -source 17 -target 17 -cp "$ANDROID_JAR:$OSMDROID_AAR_DIR/classes.jar" -d "$BUILD/classes" "$ROOT"/app/src/main/java/fr/amine/atlas/*.java "$BUILD/gen/fr/amine/atlas/R.java" "$BUILD/gen/org/osmdroid/library/R.java"
"$JAVA_HOME/bin/jar" cf "$BUILD/app.jar" -C "$BUILD/classes" .
python3 "$ROOT/tools/check-resource-linkage.py" "$OSMDROID_AAR_DIR/classes.jar" "$BUILD/app.jar"
"$BT/d8" --min-api 26 --lib "$ANDROID_JAR" --output "$BUILD/dex" "$BUILD/app.jar" "$OSMDROID_AAR_DIR/classes.jar"
python3 - "$BUILD" <<'PY'
from pathlib import Path
from zipfile import ZipFile
import sys
b=Path(sys.argv[1])
with ZipFile(b/'base.apk','a') as z:
 for p in (b/'dex').glob('*.dex'):z.write(p,p.name)
PY
"$BT/zipalign" -f 4 "$BUILD/base.apk" "$BUILD/aligned.apk"
"$BT/apksigner" sign --ks "$ROOT/dev-signing/atlas-debug.jks" --ks-pass pass:android --key-pass pass:android --out "$BUILD/Atlas-0.8.0-expedition-alpha.apk" "$BUILD/aligned.apk"
"$BT/apksigner" verify --verbose "$BUILD/Atlas-0.8.0-expedition-alpha.apk"
