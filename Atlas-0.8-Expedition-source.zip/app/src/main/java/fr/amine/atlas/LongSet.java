package fr.amine.atlas;
import java.util.*;
/** Primitive open-addressed set to avoid a boxed object per explored cell. */
public final class LongSet extends AbstractSet<Long> {
 private long[] data=new long[1024];private int count;
 private static int hash(long key){key^=key>>>33;key*=0xff51afd7ed558ccdl;key^=key>>>33;return (int)key;}
 public boolean add(Long key){return add(key.longValue());}
 public boolean add(long key){if(key<0||key==Long.MAX_VALUE)throw new IllegalArgumentException();if(count*10>=data.length*7)grow();long stored=key+1;int i=hash(key)&(data.length-1);while(data[i]!=0){if(data[i]==stored)return false;i=(i+1)&(data.length-1);}data[i]=stored;count++;return true;}
 private void grow(){long[] old=data;data=new long[old.length*2];count=0;for(long k:old)if(k!=0)add(k-1);}
 public boolean contains(Object key){if(!(key instanceof Long))return false;long k=(Long)key;int i=hash(k)&(data.length-1);while(data[i]!=0){if(data[i]==k+1)return true;i=(i+1)&(data.length-1);}return false;}
 public int size(){return count;}
 public Iterator<Long> iterator(){return new Iterator<Long>(){int index=0;public boolean hasNext(){while(index<data.length&&data[index]==0)index++;return index<data.length;}public Long next(){if(!hasNext())throw new NoSuchElementException();return data[index++]-1;}};}
}
