package fr.amine.atlas;
import android.graphics.*;
import org.osmdroid.views.*;
import org.osmdroid.views.overlay.*;
import org.osmdroid.util.GeoPoint;
import java.util.*;
/** Visual reveal only: not a coverage or territory percentage. */
public class FogOverlay extends Overlay {
 private Bitmap cached,texture;private double cachedLat,cachedLon,cachedZoom;private boolean dirty=true;private int offsetX,offsetY;private final HashSet<Long> visited=new HashSet<>();private Store.P pulse;private long pulseStart;
 private ArrayList<Store.P> points=new ArrayList<>();public boolean enabled=true;
 public void setPoints(ArrayList<Store.P> p){ArrayList<Store.P> next=p==null?new ArrayList<>():p;boolean initial=points.isEmpty();for(int i=initial?0:points.size();i<next.size();i++){Store.P point=next.get(i);boolean fresh=visited.add(Coverage.cell(point.lat,point.lon,30));if(!initial&&fresh){pulse=point;pulseStart=android.os.SystemClock.uptimeMillis();}}points=next;dirty=true;}
 public void draw(Canvas c,MapView map,boolean shadow){if(shadow||!enabled)return;
  double lat=map.getMapCenter().getLatitude(),lon=map.getMapCenter().getLongitude(),zoom=map.getZoomLevelDouble();
  if(cached==null||cached.getWidth()!=c.getWidth()||cached.getHeight()!=c.getHeight()){if(cached!=null)cached.recycle();cached=Bitmap.createBitmap(c.getWidth(),c.getHeight(),Bitmap.Config.ARGB_8888);dirty=true;}
  if(!dirty&&lat==cachedLat&&lon==cachedLon&&zoom==cachedZoom&&offsetX==map.getMapCenterOffsetX()&&offsetY==map.getMapCenterOffsetY()){c.drawBitmap(cached,0,0,null);pulse(c,map);return;}
  Canvas screen=c;c=new Canvas(cached);cached.eraseColor(Color.TRANSPARENT);
  drawFogTexture(c);
  Paint erase=new Paint(Paint.ANTI_ALIAS_FLAG);erase.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.CLEAR));erase.setStrokeCap(Paint.Cap.ROUND);erase.setStrokeJoin(Paint.Join.ROUND);
  Point last=null;Store.P prev=null;
  for(Store.P p:points){Point xy=map.getProjection().toPixels(new GeoPoint(p.lat,p.lon),null);double mpp=156543.03392*Math.cos(Math.toRadians(p.lat))/Math.pow(2,map.getZoomLevelDouble());float radius=(float)Math.max(1,Coverage.RADIUS/Math.max(.01,mpp));erase.setStyle(Paint.Style.FILL);c.drawCircle(xy.x,xy.y,radius,erase);if(prev!=null&&prev.trip==p.trip&&prev.segment==p.segment){erase.setStrokeWidth(radius*2f);c.drawLine(last.x,last.y,xy.x,xy.y,erase);}prev=p;last=xy;}
  dirty=false;cachedLat=lat;cachedLon=lon;cachedZoom=zoom;offsetX=map.getMapCenterOffsetX();offsetY=map.getMapCenterOffsetY();screen.drawBitmap(cached,0,0,null);pulse(screen,map);
 }
 private void pulse(Canvas c,MapView map){if(pulse==null)return;float fraction=(android.os.SystemClock.uptimeMillis()-pulseStart)/700f;if(fraction>=1){pulse=null;return;}Point point=map.getProjection().toPixels(new GeoPoint(pulse.lat,pulse.lon),null);float d=map.getResources().getDisplayMetrics().density;Paint paint=new Paint(3);paint.setStyle(Paint.Style.STROKE);paint.setStrokeWidth(2*d);paint.setColor(Color.argb((int)(180*(1-fraction)),242,168,76));c.drawCircle(point.x,point.y,(8+22*fraction)*d,paint);map.postInvalidateDelayed(32);}
 private void drawFogTexture(Canvas c){
  if(texture==null)texture=createTexture(512);
  Paint p=new Paint(Paint.ANTI_ALIAS_FLAG|Paint.FILTER_BITMAP_FLAG);
  p.setShader(new BitmapShader(texture,Shader.TileMode.REPEAT,Shader.TileMode.REPEAT));
  c.drawRect(0,0,c.getWidth(),c.getHeight(),p);
  Paint shade=new Paint(Paint.ANTI_ALIAS_FLAG);
  shade.setShader(new LinearGradient(0,0,0,c.getHeight(),0x14000000,0x05000000,Shader.TileMode.CLAMP));
  c.drawRect(0,0,c.getWidth(),c.getHeight(),shade);
 }
 private Bitmap createTexture(int size){
  return Bitmap.createBitmap(SmokeTexture.pixels(size),size,size,Bitmap.Config.ARGB_8888);
 }
 public void onDetach(MapView map){if(cached!=null){cached.recycle();cached=null;}if(texture!=null){texture.recycle();texture=null;}super.onDetach(map);}
}
