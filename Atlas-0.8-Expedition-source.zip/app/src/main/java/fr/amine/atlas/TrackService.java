package fr.amine.atlas;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.location.*;
import android.os.*;
public class TrackService extends Service implements LocationListener {
 public static boolean alive=false;
 public static Location lastFix;
 public static String status="Prêt à explorer";
 private long notificationAt;private int stableFixes=0; private long lastGoodNanos=0;
 private Store db;private LocationManager manager;private Location previous;private long trip=-1;private int segment;private String mode;
 public void onCreate(){super.onCreate();db=new Store(this);if(!alive)db.recover();alive=true;manager=(LocationManager)getSystemService(LOCATION_SERVICE);((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(new NotificationChannel("tracking",L.t(this,"Sortie en cours"),NotificationManager.IMPORTANCE_LOW));}
 public int onStartCommand(Intent i,int flags,int startId){
  if(i==null){stopSelf();return START_NOT_STICKY;}
  String action=i.getAction();Store.Trip current=db.active();
  if("FINISH".equals(action)){if(current!=null)db.state(current.id,"finished");status="Sortie sauvegardée";stopSelf();return START_NOT_STICKY;}
  if("PAUSE".equals(action)){if(current!=null)db.state(current.id,"paused");manager.removeUpdates(this);previous=null;status="En pause";notifyState();return START_NOT_STICKY;}
  if(checkSelfPermission(android.Manifest.permission.ACCESS_FINE_LOCATION)!=PackageManager.PERMISSION_GRANTED){status="Autorisation GPS précis nécessaire";stopSelf();return START_NOT_STICKY;}
  if(current!=null&&current.state.equals("recording")){return START_NOT_STICKY;}
  mode=current==null?i.getStringExtra("mode"):current.mode;if(mode==null)mode="Marche";
  trip=current==null?db.create(mode):current.id;if(current!=null)db.state(trip,"recording");segment=db.nextSegment(trip);previous=null;stableFixes=0;lastGoodNanos=0;
  status="Recherche du GPS…";lastFix=null;notifyState();
  try{manager.removeUpdates(this);manager.requestLocationUpdates(LocationManager.GPS_PROVIDER,1000,0,this);}catch(Exception e){db.state(trip,"interrupted");status="GPS indisponible : vérifie les réglages";stopSelf();}
  return START_NOT_STICKY;
 }
 private void notifyState(){Intent open=new Intent(this,MainActivity.class);PendingIntent p=PendingIntent.getActivity(this,0,open,PendingIntent.FLAG_IMMUTABLE|PendingIntent.FLAG_UPDATE_CURRENT);Notification n=new Notification.Builder(this,"tracking").setContentTitle(L.t(this,"Atlas · sortie active")).setContentText(L.t(this,status+" · ouvrir pour gérer la sortie")).setSmallIcon(android.R.drawable.ic_menu_mylocation).setContentIntent(p).setOngoing(true).build();startForeground(1,n);}
 public void onLocationChanged(Location l){
  if(l.hasAccuracy()&&FixPolicy.valid(SystemClock.elapsedRealtimeNanos(),l.getElapsedRealtimeNanos(),l.getAccuracy(),l.getLatitude(),l.getLongitude()))lastFix=new Location(l);if(SystemClock.elapsedRealtime()-notificationAt>10000){notificationAt=SystemClock.elapsedRealtime();notifyState();}if(trip<0)return;Store.Trip t=db.active();if(t==null||!t.state.equals("recording"))return;
  long age=(SystemClock.elapsedRealtimeNanos()-l.getElapsedRealtimeNanos())/1000000;
  if(!l.hasAccuracy()||!Geo.valid(l.getLatitude(),l.getLongitude(),l.getAccuracy(),age)){if(previous==null)stableFixes=0;status="GPS imprécis · attente d’un meilleur signal";return;}
  if(lastGoodNanos>0 && l.getElapsedRealtimeNanos()<=lastGoodNanos)return;
  if(lastGoodNanos>0 && l.getElapsedRealtimeNanos()-lastGoodNanos>8000000000L){previous=null;segment++;stableFixes=0;}
  lastGoodNanos=l.getElapsedRealtimeNanos();
  if(stableFixes<3){stableFixes++;if(stableFixes<3){status="Stabilisation GPS · "+stableFixes+"/3";return;}}
  double delta=0;
  if(previous!=null){long dt=(l.getElapsedRealtimeNanos()-previous.getElapsedRealtimeNanos())/1000000;double d=Geo.distance(previous.getLatitude(),previous.getLongitude(),l.getLatitude(),l.getLongitude());if(dt>15000){segment++;}else{if(Geo.jump(d,dt,mode)){status="Point GPS aberrant ignoré";return;}if(l.hasSpeed() && l.hasSpeedAccuracy() && l.getSpeed()+l.getSpeedAccuracyMetersPerSecond()<0.5f){status="À l’arrêt · dérive GPS filtrée";return;}if(d<Math.max(2.5,Math.min(6,Math.max(l.getAccuracy(),previous.getAccuracy())*0.45))){status="GPS prêt";return;}delta=d;}}
  db.point(trip,segment,l.getLatitude(),l.getLongitude(),System.currentTimeMillis(),l.getAccuracy(),delta,l.hasAltitude()?l.getAltitude():null,l.hasVerticalAccuracy()?(double)l.getVerticalAccuracyMeters():null);previous=new Location(l);status="GPS · rayon "+Math.round(l.getAccuracy())+" m";
 }
 public void onProviderDisabled(String provider){previous=null;stableFixes=0;lastGoodNanos=0;segment++;status="GPS désactivé · trajet interrompu";}
 public void onProviderEnabled(String provider){status="Recherche du GPS…";}
 public void onStatusChanged(String p,int s,Bundle e){}
 public void onDestroy(){if(manager!=null)manager.removeUpdates(this);if(db!=null){db.recover();db.close();}alive=false;stopForeground(true);super.onDestroy();}
 public IBinder onBind(Intent i){return null;}
}
