package fr.amine.atlas;
import android.graphics.*;
import android.location.Location;
import org.osmdroid.util.GeoPoint;
import org.osmdroid.views.MapView;
import org.osmdroid.views.overlay.Overlay;
/** Shows estimated uncertainty without clearing any fog. */
public final class PositionOverlay extends Overlay {
 private Location location;
 public void setLocation(Location l){location=l==null?null:new Location(l);}
 public void draw(Canvas c,MapView map,boolean shadow){if(shadow||location==null)return;Point pt=map.getProjection().toPixels(new GeoPoint(location.getLatitude(),location.getLongitude()),null);float density=map.getResources().getDisplayMetrics().density;double mpp=156543.03392*Math.cos(Math.toRadians(location.getLatitude()))/Math.pow(2,map.getZoomLevelDouble());float r=(float)Math.min(2000,location.getAccuracy()/Math.max(.01,mpp));Paint p=new Paint(3);p.setColor(0x26006f7d);c.drawCircle(pt.x,pt.y,r,p);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(density);p.setColor(0x88006f7d);c.drawCircle(pt.x,pt.y,r,p);p.setStyle(Paint.Style.FILL);p.setColor(Color.WHITE);c.drawCircle(pt.x,pt.y,7*density,p);p.setColor((android.os.SystemClock.elapsedRealtimeNanos()-location.getElapsedRealtimeNanos())/1000000>5000?0xff809096:0xff006f7d);c.drawCircle(pt.x,pt.y,4.5f*density,p);}
}
