package fr.amine.atlas;
import android.content.*;import android.content.res.Configuration;import java.util.*;import java.util.regex.*;import org.json.*;
/** UI-only translations; stored activity/region keys remain stable French identifiers. */
public final class L {
 private static JSONObject dictionary;private static Pattern pattern;
 private static byte[] read(java.io.InputStream in)throws java.io.IOException{java.io.ByteArrayOutputStream out=new java.io.ByteArrayOutputStream();byte[] b=new byte[4096];int n;while((n=in.read(b))!=-1)out.write(b,0,n);return out.toByteArray();}
 public static String code(Context c){String s=c.getSharedPreferences("atlas_ui",0).getString("language","fr");return Arrays.asList("fr","en","ar","es").contains(s)?s:"fr";}
 public static Locale locale(Context c){return Locale.forLanguageTag(code(c));}
 public static Context context(Context c){Configuration config=new Configuration(c.getResources().getConfiguration());config.setLocale(locale(c));config.setLayoutDirection(locale(c));return c.createConfigurationContext(config);}
 private static synchronized void load(Context c){if(dictionary!=null)return;try(java.io.InputStream in=c.getAssets().open("languages.json")){dictionary=new JSONObject(new String(read(in),java.nio.charset.StandardCharsets.UTF_8));ArrayList<String> keys=new ArrayList<>();dictionary.keys().forEachRemaining(keys::add);keys.sort((a,b)->Integer.compare(b.length(),a.length()));StringBuilder regex=new StringBuilder();for(String key:keys){if(regex.length()>0)regex.append('|');if(Character.isLetterOrDigit(key.charAt(0)))regex.append("(?<![\\p{L}\\p{N}])");regex.append(Pattern.quote(key));if(Character.isLetterOrDigit(key.charAt(key.length()-1)))regex.append("(?![\\p{L}\\p{N}])");}pattern=Pattern.compile(regex.toString());}catch(Exception e){throw new IllegalStateException("Missing language catalog",e);}}
 public static String t(Context c,CharSequence value){if(value==null)return null;String s=value.toString(),lang=code(c);if(lang.equals("fr"))return s;load(c);int column=lang.equals("en")?0:lang.equals("ar")?1:2;Matcher m=pattern.matcher(s);StringBuffer out=new StringBuffer();while(m.find()){String translated=dictionary.optJSONArray(m.group()).optString(column,m.group());m.appendReplacement(out,Matcher.quoteReplacement(translated));}m.appendTail(out);return out.toString();}
 public static String[] array(Context c,String[] values){String[] copy=values.clone();for(int i=0;i<copy.length;i++)copy[i]=t(c,copy[i]);return copy;}
}
