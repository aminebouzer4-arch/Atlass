package fr.amine.atlas;
import android.content.*;
import android.database.*;
import android.database.sqlite.*;
import java.util.*;
import java.io.*;
import java.text.*;
public class Store extends SQLiteOpenHelper {
 public Store(Context c){super(c,"atlas.db",null,3);}
 public void onCreate(SQLiteDatabase d){
  d.execSQL("CREATE TABLE trips(id INTEGER PRIMARY KEY,start INTEGER,end INTEGER,mode TEXT,state TEXT,elapsed INTEGER DEFAULT 0,anchor INTEGER DEFAULT 0)");
  d.execSQL("CREATE TABLE points(id INTEGER PRIMARY KEY,trip INTEGER,segment INTEGER,lat REAL,lon REAL,time INTEGER,accuracy REAL,delta REAL,altitude REAL,verticalAccuracy REAL)");
  d.execSQL("CREATE INDEX trip_points ON points(trip,id)");extras(d);
 }
 private static void extras(SQLiteDatabase d){d.execSQL("CREATE TABLE IF NOT EXISTS extras(id INTEGER PRIMARY KEY,kind TEXT NOT NULL,key TEXT NOT NULL,value TEXT NOT NULL,UNIQUE(kind,key))");}
 public void onUpgrade(SQLiteDatabase d,int old,int n){if(old<3)extras(d);if(old<2){d.execSQL("ALTER TABLE points ADD COLUMN altitude REAL");d.execSQL("ALTER TABLE points ADD COLUMN verticalAccuracy REAL");}}
 public static class Trip {public long id,start,end,elapsed,anchor;public String mode,state;public double meters;}
 public static class P {public long trip,time;public int segment;public double lat,lon;public Double altitude,verticalAccuracy; public P(long t,int s,double a,double b,long tm){trip=t;segment=s;lat=a;lon=b;time=tm;}}
 public long create(String mode){ContentValues v=new ContentValues();long now=System.currentTimeMillis();v.put("start",now);v.put("mode",mode);v.put("state","recording");v.put("anchor",now);return getWritableDatabase().insertOrThrow("trips",null,v);}
 public ArrayList<Trip> trips(){ArrayList<Trip> out=new ArrayList<>();try(Cursor c=getReadableDatabase().rawQuery("SELECT t.*,COALESCE((SELECT SUM(delta) FROM points p WHERE p.trip=t.id),0) AS meters FROM trips t ORDER BY id DESC",null)){while(c.moveToNext()){Trip t=new Trip();t.id=c.getLong(0);t.start=c.getLong(1);t.end=c.getLong(2);t.mode=c.getString(3);t.state=c.getString(4);t.elapsed=c.getLong(5);t.anchor=c.getLong(6);t.meters=c.getDouble(7);out.add(t);}}return out;}
 public Trip active(){for(Trip t:trips())if(!t.state.equals("finished"))return t;return null;}
 public void state(long id,String state){Trip t=active();if(t==null||t.id!=id)return;long now=System.currentTimeMillis();ContentValues v=new ContentValues();v.put("elapsed",t.elapsed+(t.state.equals("recording")?Math.max(0,now-t.anchor):0));v.put("anchor",now);v.put("state",state);if(state.equals("finished"))v.put("end",now);getWritableDatabase().update("trips",v,"id=?",new String[]{""+id});}
 public void recover(){Trip t=active();if(t!=null&&t.state.equals("recording")){long last=t.anchor;try(Cursor c=getReadableDatabase().rawQuery("SELECT MAX(time) FROM points WHERE trip=?",new String[]{""+t.id})){if(c.moveToFirst()&&!c.isNull(0))last=Math.max(last,c.getLong(0));}ContentValues v=new ContentValues();v.put("elapsed",t.elapsed+Math.max(0,last-t.anchor));v.put("state","interrupted");getWritableDatabase().update("trips",v,"id=?",new String[]{""+t.id});}}
 public int nextSegment(long id){try(Cursor c=getReadableDatabase().rawQuery("SELECT COALESCE(MAX(segment),-1)+1 FROM points WHERE trip=?",new String[]{""+id})){c.moveToFirst();return c.getInt(0);}}
 public void point(long trip,int segment,double lat,double lon,long time,float accuracy,double delta,Double altitude,Double verticalAccuracy){ContentValues v=new ContentValues();v.put("trip",trip);v.put("segment",segment);v.put("lat",lat);v.put("lon",lon);v.put("time",time);v.put("accuracy",accuracy);v.put("delta",delta);v.put("altitude",altitude);v.put("verticalAccuracy",verticalAccuracy);getWritableDatabase().insertOrThrow("points",null,v);}
 public int pointCount(){try(Cursor c=getReadableDatabase().rawQuery("SELECT COUNT(*) FROM points",null)){c.moveToFirst();return c.getInt(0);}}
 public ArrayList<P> points(long id){ArrayList<P> out=new ArrayList<>();String where=id<0?"":" WHERE trip="+id;try(Cursor c=getReadableDatabase().rawQuery("SELECT trip,segment,lat,lon,time,altitude,verticalAccuracy FROM points"+where+" ORDER BY trip,id",null)){while(c.moveToNext()){P p=new P(c.getLong(0),c.getInt(1),c.getDouble(2),c.getDouble(3),c.getLong(4));p.altitude=c.isNull(5)?null:c.getDouble(5);p.verticalAccuracy=c.isNull(6)?null:c.getDouble(6);out.add(p);}}return out;}
 /** Delete only a completed outing. The operation is atomic, so other outings and
  * the database remain intact if anything fails. Returning false means nothing changed. */
 public boolean deleteFinishedTrip(long id){
  if(id<=0||active()!=null||Backup.busy||TrackService.alive)return false;
  SQLiteDatabase d=getWritableDatabase();d.beginTransaction();
  try{
   try(Cursor c=d.rawQuery("SELECT state FROM trips WHERE id=?",new String[]{Long.toString(id)})){
    if(!c.moveToFirst()||!"finished".equals(c.getString(0)))return false;
   }
   String value=Long.toString(id);
   d.delete("points","trip=?",new String[]{value});
   d.delete("trips","id=?",new String[]{value});
   d.delete("extras","kind='terrain' AND key=?",new String[]{value});
   d.delete("extras","kind='import' AND value=?",new String[]{value});
   // Reanchor camps that belonged to the deleted outing; discard orphan buildings.
   HashMap<String,P> anchors=new HashMap<>();
   try(Cursor c=d.rawQuery("SELECT trip,segment,lat,lon,time FROM points ORDER BY id",null)){
    while(c.moveToNext()){
     P pt=new P(c.getLong(0),c.getInt(1),c.getDouble(2),c.getDouble(3),c.getLong(4));
     String key=Long.toString(Coverage.cell(pt.lat,pt.lon,250));
     if(!anchors.containsKey(key))anchors.put(key,pt);
    }
   }
   for(String key:Extras.list(this,"building").keySet())if(!anchors.containsKey(key))d.delete("extras","kind='building' AND key=?",new String[]{key});
   for(Map.Entry<String,String> entry:Extras.list(this,"kingdom").entrySet()){
    if(!entry.getKey().startsWith("camp:"))continue;
    String cell=entry.getKey().substring(5);P anchor=anchors.get(cell);
    if(anchor==null){d.delete("extras","kind='kingdom' AND key=?",new String[]{entry.getKey()});continue;}
    try{
     org.json.JSONObject saved=new org.json.JSONObject(entry.getValue());
     if(saved.getLong("trip")==id)Extras.put(this,"kingdom",entry.getKey(),
      new org.json.JSONObject().put("trip",anchor.trip).put("lat",anchor.lat).put("lon",anchor.lon).toString());
    }catch(org.json.JSONException ex){throw new IllegalStateException("Camp enregistré invalide",ex);}
   }
   d.setTransactionSuccessful();return true;
  }finally{d.endTransaction();}
 }
 public void export(long id,OutputStream stream)throws IOException{SimpleDateFormat f=new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'",Locale.US);f.setTimeZone(TimeZone.getTimeZone("UTC"));try(Writer w=new OutputStreamWriter(stream,java.nio.charset.StandardCharsets.UTF_8)){w.write("<?xml version=\"1.0\" encoding=\"UTF-8\"?><gpx version=\"1.1\" creator=\"Atlas\" xmlns=\"http://www.topografix.com/GPX/1/1\"><trk><name>Sortie Atlas</name>");int seg=-1;for(P p:points(id)){if(seg!=p.segment){if(seg!=-1)w.write("</trkseg>");w.write("<trkseg>");seg=p.segment;}w.write("<trkpt lat=\""+p.lat+"\" lon=\""+p.lon+"\"><time>"+f.format(new Date(p.time))+"</time></trkpt>");}if(seg!=-1)w.write("</trkseg>");w.write("</trk></gpx>");}}
}
