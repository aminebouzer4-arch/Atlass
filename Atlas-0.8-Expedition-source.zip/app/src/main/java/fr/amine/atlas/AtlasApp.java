package fr.amine.atlas;
import android.app.Application;
import java.io.*;
/** Local-only crash report; no analytics or upload. */
public class AtlasApp extends Application {
 public void onCreate(){super.onCreate();Thread.UncaughtExceptionHandler original=Thread.getDefaultUncaughtExceptionHandler();Thread.setDefaultUncaughtExceptionHandler((thread,error)->{try(PrintWriter out=new PrintWriter(new File(getFilesDir(),"last-crash.txt"))){out.println("Atlas 0.2.1 - diagnostic local");error.printStackTrace(out);}catch(Exception ignored){}if(original!=null)original.uncaughtException(thread,error);else android.os.Process.killProcess(android.os.Process.myPid());});}
}
