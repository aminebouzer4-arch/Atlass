package fr.amine.atlas;
import android.content.ContentValues;import android.database.Cursor;import java.util.*;
public final class Extras {
 public static void put(Store s,String kind,String key,String value){ContentValues v=new ContentValues();v.put("kind",kind);v.put("key",key);v.put("value",value);s.getWritableDatabase().insertWithOnConflict("extras",null,v,android.database.sqlite.SQLiteDatabase.CONFLICT_REPLACE);}
 public static LinkedHashMap<String,String> list(Store s,String kind){LinkedHashMap<String,String> out=new LinkedHashMap<>();try(Cursor c=s.getReadableDatabase().rawQuery("SELECT key,value FROM extras WHERE kind=? ORDER BY id",new String[]{kind})){while(c.moveToNext())out.put(c.getString(0),c.getString(1));}return out;}
 public static String get(Store s,String kind,String key){try(Cursor c=s.getReadableDatabase().rawQuery("SELECT value FROM extras WHERE kind=? AND key=?",new String[]{kind,key})){return c.moveToFirst()?c.getString(0):null;}}
 public static void delete(Store s,String kind,String key){s.getWritableDatabase().delete("extras","kind=? AND key=?",new String[]{kind,key});}
}
