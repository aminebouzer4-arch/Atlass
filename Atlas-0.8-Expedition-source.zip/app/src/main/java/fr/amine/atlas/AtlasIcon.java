package fr.amine.atlas;
import android.graphics.*;
import android.graphics.drawable.Drawable;
/** Small vector icons drawn at any display density. */
public final class AtlasIcon extends Drawable {
 private final String name;private final int size,color;
 public AtlasIcon(String name,int size,int color){this.name=name;this.size=size;this.color=color;setBounds(0,0,size,size);}
 public int getIntrinsicWidth(){return size;}public int getIntrinsicHeight(){return size;}
 public void setAlpha(int a){}public void setColorFilter(ColorFilter f){}public int getOpacity(){return PixelFormat.TRANSLUCENT;}
 public void draw(Canvas c){int save=c.save();c.translate(getBounds().left,getBounds().top);c.scale(getBounds().width()/24f,getBounds().height()/24f);Paint p=new Paint(3);p.setColor(color);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(1.65f);p.setStrokeCap(Paint.Cap.ROUND);p.setStrokeJoin(Paint.Join.ROUND);
 switch(name){
 case "Locate":c.drawCircle(12,12,6,p);c.drawCircle(12,12,2,p);line(c,p,12,2,12,5);line(c,p,12,19,12,22);line(c,p,2,12,5,12);line(c,p,19,12,22,12);break;
 case "Follow":line(c,p,3,10,21,3,14,21,10,14,3,10);break;
 case "Layers":line(c,p,3,8,12,3,21,8,12,13,3,8);line(c,p,3,13,12,18,21,13);line(c,p,3,17,12,22,21,17);break;
 case "Full":line(c,p,3,9,3,3,9,3);line(c,p,15,3,21,3,21,9);line(c,p,3,15,3,21,9,21);line(c,p,15,21,21,21,21,15);break;
 case "ExitFull":line(c,p,3,9,9,9,9,3);line(c,p,15,3,15,9,21,9);line(c,p,3,15,9,15,9,21);line(c,p,15,21,15,15,21,15);break;
 case "Expand":line(c,p,5,15,12,8,19,15);break;
 case "Collapse":line(c,p,5,9,12,16,19,9);break;
 case "Pause":line(c,p,8,5,8,19);line(c,p,16,5,16,19);break;
 case "Shield":line(c,p,4,4,12,2,20,4,19,15,12,22,5,15,4,4);break;
 case "Star":line(c,p,12,2,15,8,22,9,17,14,18,21,12,18,6,21,7,14,2,9,9,8,12,2);break;
 case "Mountain":line(c,p,2,20,10,5,15,13,18,9,23,20,2,20);break;

 case "Marche":c.drawCircle(13,4,2,p);line(c,p,11,8,14,8,16,13,20,14);line(c,p,11,8,8,13,4,14);line(c,p,13,9,11,15,7,21);line(c,p,11,15,15,17,16,22);break;
 case "Course":c.drawCircle(16,4,2,p);line(c,p,5,9,10,7,14,10,18,12,21,9);line(c,p,14,10,10,15,5,15,2,19);line(c,p,10,15,15,17,12,22);break;
 case "Vélo":c.drawCircle(5,17,4,p);c.drawCircle(19,17,4,p);line(c,p,5,17,10,8,15,17,5,17);line(c,p,10,8,17,8,19,17);line(c,p,15,4,18,4,17,8);line(c,p,8,7,12,7);break;
 case "Voiture":c.drawRoundRect(3,10,21,18,2,2,p);line(c,p,5,10,7,5,17,5,19,10);line(c,p,6,18,6,21);line(c,p,18,18,18,21);line(c,p,6,13,8,13);line(c,p,16,13,18,13);break;
 case "Carnet":c.drawRoundRect(5,3,20,21,2,2,p);line(c,p,9,3,9,21);line(c,p,12,8,17,8);line(c,p,12,12,16,12);break;
 case "Réglages":for(int y=6;y<=18;y+=6){line(c,p,3,y,21,y);c.drawCircle(y==12?16:8,y,2,p);}break;
 default:c.drawCircle(12,12,9,p);line(c,p,16,7,13,14,8,17,11,10,16,7);break;
 }c.restoreToCount(save);}
 private static void line(Canvas c,Paint p,float... xy){Path path=new Path();path.moveTo(xy[0],xy[1]);for(int i=2;i<xy.length;i+=2)path.lineTo(xy[i],xy[i+1]);c.drawPath(path,p);}
}
