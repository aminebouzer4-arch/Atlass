package fr.amine.atlas;

import android.app.Activity;
import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Button;
import org.osmdroid.config.Configuration;
import org.osmdroid.views.MapView;
import java.util.ArrayList;

/** Full-screen map of one archived outing: zoom, pan, and retained fog-of-war. */
public final class TripMapActivity extends Activity {
 private Store store;private MapView map;
 @Override protected void attachBaseContext(Context context){super.attachBaseContext(L.context(context));}
 @Override public void onCreate(Bundle state){
  super.onCreate(state);
  Configuration.getInstance().setOsmdroidBasePath(new java.io.File(getCacheDir(),"maps"));
  Configuration.getInstance().setOsmdroidTileCache(new java.io.File(getCacheDir(),"maps/tiles"));
  Configuration.getInstance().setUserAgentValue("fr.amine.atlas/0.8.0-expedition-alpha");
  getWindow().setStatusBarColor(0xff101d29);
  getWindow().setNavigationBarColor(0xff101d29);
  store=new Store(this);
  long trip=getIntent().getLongExtra("trip",-1);
  if(trip<=0){finish();return;}
  ArrayList<Store.P> pts=store.points(trip);
  boolean topo=getIntent().getBooleanExtra("topo",true);
  boolean offline=getIntent().getBooleanExtra("offline",false);
  FrameLayout root=new FrameLayout(this);root.setBackgroundColor(0xff14212c);setContentView(root);
  map=TripMaps.create(this,pts,store.points(-1),topo,offline);
  root.addView(map,new FrameLayout.LayoutParams(-1,-1));
  LinearLayout header=new LinearLayout(this);header.setGravity(Gravity.CENTER_VERTICAL);
  header.setPadding(dp(12),dp(8),dp(12),dp(8));header.setBackgroundColor(0xf0102a34);
  Button back=new Button(this);back.setText("‹");back.setTextSize(29);back.setTextColor(Color.WHITE);
  back.setBackgroundColor(Color.TRANSPARENT);header.addView(back,new LinearLayout.LayoutParams(dp(50),dp(52)));
  back.setContentDescription(L.t(this,"Retour au carnet"));back.setOnClickListener(v->finish());
  TextView title=new TextView(this);title.setText(L.t(this,"Parcours sur la carte"));title.setTextSize(18);
  title.setTypeface(null,Typeface.BOLD);title.setTextColor(Color.WHITE);
  header.addView(title,new LinearLayout.LayoutParams(0,-2,1));
  FrameLayout.LayoutParams h=new FrameLayout.LayoutParams(-1,-2,Gravity.TOP);root.addView(header,h);
  if(pts.isEmpty()){
   TextView empty=new TextView(this);empty.setText(L.t(this,"Aucun point GPS enregistré pour cette sortie."));
   empty.setBackgroundColor(0xee152332);empty.setTextColor(Color.WHITE);empty.setTextSize(16);
   empty.setPadding(dp(20),dp(20),dp(20),dp(20));
   FrameLayout.LayoutParams p=new FrameLayout.LayoutParams(-1,-2,Gravity.CENTER);
   p.setMargins(dp(20),0,dp(20),0);root.addView(empty,p);
  }
 }
 private int dp(int value){return Math.round(value*getResources().getDisplayMetrics().density);}
 @Override protected void onResume(){super.onResume();if(map!=null)map.onResume();}
 @Override protected void onPause(){if(map!=null)map.onPause();super.onPause();}
 @Override protected void onDestroy(){if(map!=null)map.onDetach();if(store!=null)store.close();super.onDestroy();}
}
