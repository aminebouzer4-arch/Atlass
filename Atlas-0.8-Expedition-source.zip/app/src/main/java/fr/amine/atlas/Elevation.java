package fr.amine.atlas;
import java.util.*;
/** Conservative GPS ascent estimate; never substitutes missing height with zero. */
public final class Elevation {
 public static class Result { public double up,down; public int usable; public boolean available(){return usable>=5;} }
 public static Result calculate(List<Store.P> points){
  Result r=new Result();ArrayList<Double> window=new ArrayList<>();double anchor=Double.NaN;long trip=-1;int segment=-1;
  for(Store.P p:points){
   if(p.trip!=trip||p.segment!=segment){window.clear();anchor=Double.NaN;trip=p.trip;segment=p.segment;}
   if(p.altitude==null||p.verticalAccuracy==null||p.verticalAccuracy>10||!Double.isFinite(p.altitude)){window.clear();anchor=Double.NaN;continue;}
   window.add(p.altitude);if(window.size()>5)window.remove(0);if(window.size()<5)continue;
   r.usable++;ArrayList<Double> sorted=new ArrayList<>(window);Collections.sort(sorted);double z=sorted.get(2);
   if(Double.isNaN(anchor)){anchor=z;continue;}double delta=z-anchor;
   if(Math.abs(delta)>=Math.max(5,1.5*p.verticalAccuracy)){if(delta>0)r.up+=delta;else r.down-=delta;anchor=z;}
  }return r;
 }
}
