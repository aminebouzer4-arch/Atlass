package fr.amine.atlas;
/** Deterministic seamless cloud texture. Every pixel is opaque, independent of map tiles. */
public final class SmokeTexture {
 private static double mix(double a,double b,double t){return a+(b-a)*t;}
 private static double hash(int x,int y,int period){x=Math.floorMod(x,period);y=Math.floorMod(y,period);int h=x*374761393+y*668265263+20261020;h=(h^(h>>>13))*1274126177;return ((h^(h>>>16))&0x7fffffff)/(double)0x7fffffff;}
 private static double noise(double x,double y,int period){int ix=(int)Math.floor(x),iy=(int)Math.floor(y);double u=x-ix,v=y-iy;u=u*u*(3-2*u);v=v*v*(3-2*v);return mix(mix(hash(ix,iy,period),hash(ix+1,iy,period),u),mix(hash(ix,iy+1,period),hash(ix+1,iy+1,period),u),v);}
 private static double cloud(double x,double y){double value=0,weight=.55;for(int n=4;n<=64;n*=2){value+=weight*noise(x*n,y*n,n);weight*=.5;}return value;}
 public static int[] pixels(int size){int[] out=new int[size*size];for(int y=0;y<size;y++)for(int x=0;x<size;x++){double u=x/(double)size,v=y/(double)size;double wx=cloud(u+.31,v+.17),wy=cloud(u+.71,v+.63);double c=cloud(u+.25*wx,v+.25*wy);double grain=(hash(x,y,size)-.5)*7;int r=(int)Math.max(22,Math.min(63,26+29*c+grain));int g=(int)Math.max(34,Math.min(77,38+30*c+grain));int b=(int)Math.max(40,Math.min(83,46+29*c+grain));out[y*size+x]=0xff000000|(r<<16)|(g<<8)|b;}return out;}
}
