package fr.amine.atlas;
import java.io.*;import java.net.*;import java.nio.charset.StandardCharsets;
public final class Net {
 private static long lastRequest;public static synchronized String get(String url,int limit)throws Exception{return request(url,null,limit);}
 public static synchronized String post(String url,String data,int limit)throws Exception{return request(url,data,limit);}
 private static String request(String url,String body,int limit)throws Exception{long wait=1100-(System.currentTimeMillis()-lastRequest);if(wait>0)Thread.sleep(wait);lastRequest=System.currentTimeMillis();HttpURLConnection c=(HttpURLConnection)new URL(url).openConnection();c.setConnectTimeout(20000);c.setReadTimeout(45000);c.setRequestProperty("User-Agent","AtlasPersonalAndroid/0.5 (fr.amine.atlas; personal exploration)");c.setRequestProperty("Accept","application/json");try{if(body!=null){c.setRequestMethod("POST");c.setDoOutput(true);c.setRequestProperty("Content-Type","application/x-www-form-urlencoded");try(OutputStream out=c.getOutputStream()){out.write(body.getBytes(StandardCharsets.UTF_8));}}int code=c.getResponseCode();if(code!=200)throw new IOException(code==429?"Service occupé : réessaie plus tard.":"Le service distant répond "+code+". Réessaie plus tard.");try(InputStream in=c.getInputStream()){return new String(read(in,limit),StandardCharsets.UTF_8);}}finally{c.disconnect();}}
 public static byte[] read(InputStream in,int max)throws IOException{ByteArrayOutputStream out=new ByteArrayOutputStream();byte[] b=new byte[8192];int n;while((n=in.read(b))!=-1){if(out.size()+n>max)throw new IOException("Fichier trop volumineux.");out.write(b,0,n);}return out.toByteArray();}
 public static String encode(String s)throws Exception{return URLEncoder.encode(s,"UTF-8");}
}
