package fr.amine.atlas;
import java.util.*;
/** Latitude bands with approximately 4 m cells; exact spherical cell areas.
 * Corridor rasterised at 5 m along-track spacing, not exact surveyed coverage. */
public final class Coverage {
 public static final double R=6371008.8,STEP=4,RADIUS=30;
 public final LongSet cells=new LongSet();public final Set<Long> territories=new LinkedHashSet<>();public double squareMeters;
 public static int rows(double step){return (int)Math.ceil(Math.PI*R/step);}
 public static int row(double lat,double step){return Math.max(0,Math.min(rows(step)-1,(int)Math.floor((lat+90)/180*rows(step))));}
 public static double latitude(int row,double step){return -90+(row+.5)*180/rows(step);}
 public static int columns(int row,double step){return Math.max(1,(int)Math.round(2*Math.PI*R*Math.cos(Math.toRadians(latitude(row,step)))/step));}
 public static long key(int row,int col){return ((long)row<<32)|(col&0xffffffffL);}
 public static int row(long k){return (int)(k>>>32);}public static int col(long k){return (int)k;}
 public static long cell(double lat,double lon,double step){int row=row(lat,step),n=columns(row,step);int col=(int)Math.floor(((lon+180)%360+360)%360/360*n);return key(row,Math.min(n-1,col));}
 public static double lat(long k,double step){return latitude(row(k),step);}public static double lon(long k,double step){return -180+(col(k)+.5)*360/columns(row(k),step);}
 public static double area(long k,double step){int row=row(k),n=rows(step);return R*R*2*Math.PI/columns(row,step)*(Math.sin(Math.toRadians(-90+(row+1)*180.0/n))-Math.sin(Math.toRadians(-90+row*180.0/n)));}
 public static Coverage calculate(List<Store.P> points){Coverage result=new Coverage();Store.P previous=null;for(Store.P p:points){if(!Double.isFinite(p.lat)||!Double.isFinite(p.lon))continue;double distance=previous!=null&&previous.trip==p.trip&&previous.segment==p.segment?Geo.distance(previous.lat,previous.lon,p.lat,p.lon):0;int steps=Math.max(1,(int)Math.ceil(distance/5));if(steps>20000)throw new IllegalArgumentException("Segment trop long : vérifie le GPX.");double fromLat=distance>0?previous.lat:p.lat,fromLon=distance>0?previous.lon:p.lon,dlon=((p.lon-fromLon+540)%360)-180;for(int i=0;i<=steps;i++){double f=(double)i/steps;result.addDisk(fromLat+(p.lat-fromLat)*f,((fromLon+dlon*f+540)%360)-180);}previous=p;}return result;}
 private void addDisk(double lat,double lon){territories.add(cell(lat,lon,250));int base=row(lat,STEP);for(int r=Math.max(0,base-10);r<=Math.min(rows(STEP)-1,base+10);r++){double la=latitude(r,STEP);int n=columns(r,STEP),center=(int)Math.floor((lon+180)/360*n);for(int dx=-10;dx<=10;dx++){int col=((center+dx)%n+n)%n;long k=key(r,col);if(Geo.distance(lat,lon,la,lon(k,STEP))<=RADIUS&&cells.add(k)){squareMeters+=area(k,STEP);if(cells.size()>4000000)throw new IllegalArgumentException("Plus de quatre millions de cellules : calcul trop volumineux pour cette version.");}}}}
 public double within(Boundary b){double sum=0;for(long k:cells)if(b.contains(lat(k,STEP),lon(k,STEP)))sum+=area(k,STEP);return Math.min(sum,b.squareMeters);}
}
