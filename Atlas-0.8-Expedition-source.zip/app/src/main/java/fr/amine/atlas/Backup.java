package fr.amine.atlas;
import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.JsonReader;
import android.util.JsonWriter;
import android.util.JsonToken;
import java.io.*;
import java.util.*;
/** Portable backup. Restore is validated and atomic; malformed input rolls back. */
public final class Backup {
 public static volatile boolean busy=false;
 private static final String[] EXTRAS={"id","kind","key","value"};
 private static final String[] TRIPS={"id","start","end","mode","state","elapsed","anchor"};
 private static final String[] POINTS={"id","trip","segment","lat","lon","time","accuracy","delta","altitude","verticalAccuracy"};
 public static void save(Store store,OutputStream out)throws IOException{
  if(store.active()!=null)throw new IOException("Termine la sortie en cours avant la sauvegarde.");
  SQLiteDatabase db=store.getReadableDatabase();db.beginTransaction();
  try(JsonWriter w=new JsonWriter(new OutputStreamWriter(out,"UTF-8"))){w.beginObject().name("format").value("atlas-backup").name("version").value(2);writeTable(db,w,"trips",TRIPS);writeTable(db,w,"points",POINTS);writeTable(db,w,"extras",EXTRAS);w.endObject();db.setTransactionSuccessful();}finally{db.endTransaction();}
 }
 private static void writeTable(SQLiteDatabase db,JsonWriter w,String table,String[] columns)throws IOException{w.name(table).beginArray();try(Cursor c=db.query(table,columns,null,null,null,null,"id")){while(c.moveToNext()){w.beginObject();for(int i=0;i<columns.length;i++){w.name(columns[i]);switch(c.getType(i)){case Cursor.FIELD_TYPE_NULL:w.nullValue();break;case Cursor.FIELD_TYPE_INTEGER:w.value(c.getLong(i));break;case Cursor.FIELD_TYPE_FLOAT:w.value(c.getDouble(i));break;default:w.value(c.getString(i));}}w.endObject();}}w.endArray();}
 public static void restore(Store store,InputStream input)throws IOException{
  if(store.active()!=null)throw new IOException("Termine la sortie en cours avant la restauration.");
  SQLiteDatabase db=store.getWritableDatabase();db.beginTransaction();
  try(JsonReader r=new JsonReader(new InputStreamReader(new LimitedInput(input),"UTF-8"))){
   r.beginObject();require(r.nextName().equals("format")&&r.nextString().equals("atlas-backup"));require(r.nextName().equals("version"));int version=r.nextInt();require(version==1||version==2);require(r.nextName().equals("trips"));
   db.delete("extras",null,null);db.delete("points",null,null);db.delete("trips",null,null);HashSet<Long> ids=new HashSet<>();r.beginArray();while(r.hasNext()){ContentValues v=readRow(r,TRIPS);long id=number(v,"id").longValue();require(id>0&&ids.add(id));require("finished".equals(v.getAsString("state")));require(Arrays.asList("Marche","Course","Vélo","Voiture").contains(v.getAsString("mode")));require(number(v,"elapsed").longValue()>=0);db.insertOrThrow("trips",null,v);}r.endArray();require(r.nextName().equals("points"));r.beginArray();while(r.hasNext()){ContentValues v=readRow(r,POINTS);require(ids.contains(number(v,"trip").longValue()));require(number(v,"id").longValue()>0&&number(v,"segment").longValue()>=0);double lat=number(v,"lat").doubleValue(),lon=number(v,"lon").doubleValue();require(Math.abs(lat)<=90&&Math.abs(lon)<=180&&number(v,"delta").doubleValue()>=0&&number(v,"accuracy").doubleValue()>0);db.insertOrThrow("points",null,v);}r.endArray();if(version==2){require(r.nextName().equals("extras"));r.beginArray();while(r.hasNext()){ContentValues v=readRow(r,EXTRAS);require(number(v,"id").longValue()>0);String kind=v.getAsString("kind"),key=v.getAsString("key"),value=v.getAsString("value");require(Arrays.asList("region","search","terrain","import","building","kingdom").contains(kind)&&key.length()>0&&key.length()<2000&&value.length()<16000000);if(kind.equals("building")){require(Long.parseLong(key)>=0);int level=Integer.parseInt(value);require(level>=1&&level<=3);}else if(kind.equals("kingdom")){if(key.equals("name"))require(value.length()<=40);else if(key.equals("color"))require(Arrays.asList(-16745341,-14326805,-2729414,-13077173).contains(Integer.parseInt(value)));else if(key.equals("emblem"))require(Arrays.asList("Shield","Star","Mountain").contains(value));else if(key.startsWith("camp:")){require(Long.parseLong(key.substring(5))>=0);org.json.JSONObject a=new org.json.JSONObject(value);require(ids.contains(a.getLong("trip"))&&Math.abs(a.getDouble("lat"))<=90&&Math.abs(a.getDouble("lon"))<=180);}else require(false);}else if(kind.equals("import")){require(ids.contains(Long.parseLong(value)));}else if(kind.equals("terrain")){require(ids.contains(Long.parseLong(key)));new org.json.JSONObject(value);}else if(kind.equals("region")){new org.json.JSONObject(value);}else new org.json.JSONArray(value);db.insertOrThrow("extras",null,v);}r.endArray();}r.endObject();require(r.peek()==JsonToken.END_DOCUMENT);db.setTransactionSuccessful();
  }catch(Exception e){throw new IOException("Sauvegarde invalide ou incompatible. Tes données sont conservées.",e);}finally{db.endTransaction();}
 }
 private static ContentValues readRow(JsonReader r,String[] columns)throws IOException{ContentValues v=new ContentValues();Set<String> expected=new HashSet<>(Arrays.asList(columns));r.beginObject();while(r.hasNext()){String k=r.nextName();require(expected.remove(k));if(r.peek()==JsonToken.NULL){r.nextNull();require(k.equals("altitude")||k.equals("verticalAccuracy"));v.putNull(k);}else if(k.equals("mode")||k.equals("state")||k.equals("kind")||k.equals("key")||k.equals("value"))v.put(k,r.nextString());else if(Arrays.asList("lat","lon","accuracy","delta","altitude","verticalAccuracy").contains(k)){double n=r.nextDouble();require(Double.isFinite(n));v.put(k,n);}else v.put(k,r.nextLong());}r.endObject();require(expected.isEmpty());return v;}
 private static Number number(ContentValues v,String k)throws IOException{Object n=v.get(k);require(n instanceof Number);return (Number)n;}
 private static void require(boolean ok)throws IOException{if(!ok)throw new IOException("Sauvegarde invalide ou incompatible. Tes données sont conservées.");}
 private static class LimitedInput extends FilterInputStream{long remaining=100L*1024*1024;LimitedInput(InputStream i){super(i);}public int read()throws IOException{if(--remaining<0)throw new IOException("Sauvegarde trop volumineuse (100 Mo maximum).");return super.read();}public int read(byte[] b,int o,int l)throws IOException{if(remaining<=0)throw new IOException("Sauvegarde trop volumineuse (100 Mo maximum).");int n=super.read(b,o,(int)Math.min(l,remaining));if(n>0)remaining-=n;return n;}}
}
