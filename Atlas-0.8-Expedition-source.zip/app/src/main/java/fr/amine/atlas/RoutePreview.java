package fr.amine.atlas;
import android.content.Context;
import android.graphics.*;
import android.view.View;
import java.util.ArrayList;
/** Actual recorded shape, not a geographic basemap. */
public final class RoutePreview extends View {
 private final ArrayList<Store.P> points;private final Paint p=new Paint(3);
 public RoutePreview(Context c,ArrayList<Store.P> ps){super(c);points=ps;setContentDescription("Aperçu du tracé enregistré");}
 protected void onDraw(Canvas c){super.onDraw(c);float d=getResources().getDisplayMetrics().density;c.drawColor(0xff102934);if(points.isEmpty()){p.setColor(Expedition.MUTED);p.setTextSize(12*d);c.drawText("Aucun point GPS enregistré",16*d,getHeight()/2f,p);return;}double minX=1e20,minY=1e20,maxX=-1e20,maxY=-1e20,lon=points.get(0).lon,lat=points.get(0).lat;for(Store.P q:points){double x=x(q,lon,lat);minX=Math.min(minX,x);maxX=Math.max(maxX,x);minY=Math.min(minY,q.lat);maxY=Math.max(maxY,q.lat);}double scale=Math.min((getWidth()-40*d)/Math.max(1e-6,maxX-minX),(getHeight()-40*d)/Math.max(1e-6,maxY-minY));float ox=getWidth()/2f,oy=getHeight()/2f;p.setColor(Expedition.ACCENT_BRIGHT);p.setStrokeWidth(3*d);p.setStyle(Paint.Style.STROKE);p.setStrokeCap(Paint.Cap.ROUND);p.setStrokeJoin(Paint.Join.ROUND);Path path=new Path();Store.P prev=null;float lastX=ox,lastY=oy;for(Store.P q:points){float xx=(float)(ox+(x(q,lon,lat)-(minX+maxX)/2)*scale),yy=(float)(oy-(q.lat-(minY+maxY)/2)*scale);if(prev==null||prev.segment!=q.segment)path.moveTo(xx,yy);else path.lineTo(xx,yy);prev=q;lastX=xx;lastY=yy;}c.drawPath(path,p);p.setStyle(Paint.Style.FILL);p.setColor(0xfff5b76c);c.drawCircle(lastX,lastY,5*d,p);}
 private double x(Store.P q,double lon,double lat){return ((q.lon-lon+540)%360-180)*Math.cos(Math.toRadians(lat));}
}
