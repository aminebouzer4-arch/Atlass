package fr.amine.atlas;
/** Pure geometry, independently testable without Android. */
public final class Geo {
 public static double distance(double a,double b,double c,double d){
  double x=Math.toRadians(c-a),y=Math.toRadians(d-b);
  double h=Math.sin(x/2)*Math.sin(x/2)+Math.cos(Math.toRadians(a))*Math.cos(Math.toRadians(c))*Math.sin(y/2)*Math.sin(y/2);
  return 6371008.8*2*Math.asin(Math.sqrt(Math.max(0,Math.min(1,h))));
 }
 public static boolean valid(double lat,double lon,float accuracy,long ageMs){return Double.isFinite(lat)&&Double.isFinite(lon)&&Math.abs(lat)<=90&&Math.abs(lon)<=180&&Float.isFinite(accuracy)&&accuracy>0&&accuracy<=15&&ageMs>=0&&ageMs<=5000;}
 public static boolean jump(double meters,long dtMs,String mode){double limit="Voiture".equals(mode)?70:("Vélo".equals(mode)?30:12);return dtMs<=0||meters/(dtMs/1000.0)>limit;}
}
