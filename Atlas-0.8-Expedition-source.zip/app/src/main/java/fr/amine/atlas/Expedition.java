package fr.amine.atlas;
import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
/** Atlas Expedition: one coherent night-time visual system shared by the whole application. */
public final class Expedition {
 private Expedition(){}
 public static final int BACKGROUND=0xff07161d;
 public static final int NAV=0xff0b2029;
 public static final int SURFACE=0xff102a34;
 public static final int SURFACE_RAISED=0xff193642;
 public static final int BORDER=0xff31525a;
 public static final int TEXT=0xfff0faf7;
 public static final int MUTED=0xff9bb5bc;
 public static final int ACCENT=0xff11c8ad;
 public static final int ACCENT_BRIGHT=0xff56ebd0;
 public static final int DANGER=0xffff847a;
 static int dp(Context c,int n){return Math.round(n*c.getResources().getDisplayMetrics().density);}
 public static GradientDrawable card(Context c,int radius){
  GradientDrawable g=new GradientDrawable(GradientDrawable.Orientation.TL_BR,
   new int[]{0xff193843,0xff102631});
  g.setCornerRadius(dp(c,radius));g.setStroke(dp(c,1),BORDER);return g;
 }
 public static GradientDrawable solid(Context c,int color,int radius){
  GradientDrawable g=new GradientDrawable();g.setColor(color);g.setCornerRadius(dp(c,radius));return g;
 }
 public static GradientDrawable outline(Context c,int color,int radius){
  GradientDrawable g=solid(c,color,radius);g.setStroke(dp(c,1),BORDER);return g;
 }
}
