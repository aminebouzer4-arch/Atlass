package fr.amine.atlas;
import android.graphics.Canvas;
import android.graphics.Paint;
import org.osmdroid.views.MapView;
import org.osmdroid.views.overlay.Overlay;
/** Dims exposed map tiles to Expedition night palette; the opaque fog draws afterwards. */
public final class NightMapOverlay extends Overlay {
 private final Paint tint=new Paint(3);
 public NightMapOverlay(){tint.setColor(0x97051c25);}
 @Override public void draw(Canvas canvas,MapView map,boolean shadow){
  if(!shadow)canvas.drawRect(0,0,canvas.getWidth(),canvas.getHeight(),tint);
 }
}
