package fr.amine.atlas;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Point;
import org.osmdroid.tileprovider.tilesource.TileSourceFactory;
import org.osmdroid.tileprovider.tilesource.XYTileSource;
import org.osmdroid.util.BoundingBox;
import org.osmdroid.util.GeoPoint;
import org.osmdroid.views.CustomZoomButtonsController;
import org.osmdroid.views.MapView;
import org.osmdroid.views.overlay.Polyline;
import org.osmdroid.views.overlay.Overlay;
import java.util.ArrayList;

/** Shared interactive basemap for one historical outing, not the main live map. */
public final class TripMaps {
 private TripMaps(){}
 public static MapView create(Context context,ArrayList<Store.P> route,ArrayList<Store.P> explored,boolean topo,boolean offline){
  MapView map=new MapView(context);
  map.setMultiTouchControls(true);
  map.getZoomController().setVisibility(CustomZoomButtonsController.Visibility.NEVER);
  if(topo){
   map.setTileSource(new XYTileSource("OpenTopoMap",0,17,256,".png",new String[]{"https://a.tile.opentopomap.org/","https://b.tile.opentopomap.org/","https://c.tile.opentopomap.org/"},"© OpenStreetMap, SRTM | OpenTopoMap CC-BY-SA"));
   map.setMaxZoomLevel(17.0);
  }else{
   map.setTileSource(TileSourceFactory.MAPNIK);
   map.setMaxZoomLevel(19.0);
  }
  map.setUseDataConnection(!offline);
  if(offline)map.getOverlays().add(new OfflineOverlay(context));
  map.getOverlays().add(new NightMapOverlay());
  FogOverlay fog=new FogOverlay();
  fog.setPoints(explored);
  map.getOverlays().add(fog);
  Polyline line=null;Store.P prev=null;
  for(Store.P pt:route){
   if(!Double.isFinite(pt.lat)||!Double.isFinite(pt.lon))continue;
   if(prev==null||pt.segment!=prev.segment||pt.trip!=prev.trip){
    line=new Polyline(map);
    line.getOutlinePaint().setColor(0xff08c7be);
    line.getOutlinePaint().setStrokeWidth(5*context.getResources().getDisplayMetrics().density);
    map.getOverlays().add(line);
   }
   line.addPoint(new GeoPoint(pt.lat,pt.lon));
   prev=pt;
  }
  if(!route.isEmpty())map.getOverlays().add(new EndpointOverlay(route.get(0),route.get(route.size()-1)));
  fit(map,route,context);
  return map;
 }
 /** Start (turquoise) and finish (amber) remain visible over the map's fog. */
 private static final class EndpointOverlay extends Overlay {
  final Store.P start,finish;final Paint paint=new Paint(3);
  EndpointOverlay(Store.P s,Store.P f){start=s;finish=f;}
  @Override public void draw(Canvas canvas,MapView map,boolean shadow){
   if(shadow)return;
   float d=map.getResources().getDisplayMetrics().density;
   marker(canvas,map,start,0xff05bcb1,d);
   marker(canvas,map,finish,0xfff5ab50,d);
  }
  private void marker(Canvas c,MapView map,Store.P p,int color,float d){
   Point xy=map.getProjection().toPixels(new GeoPoint(p.lat,p.lon),null);
   paint.setStyle(Paint.Style.FILL);paint.setColor(0xff14212c);c.drawCircle(xy.x,xy.y,7*d,paint);
   paint.setColor(color);c.drawCircle(xy.x,xy.y,4.6f*d,paint);
  }
 }
 private static void fit(MapView map,ArrayList<Store.P> pts,Context c){
  if(pts.isEmpty()){
   map.getController().setZoom(5.0);
   map.getController().setCenter(new GeoPoint(36.7525,3.042));
   return;
  }
  double south=90,north=-90,west=180,east=-180;
  for(Store.P pt:pts){
   if(!Double.isFinite(pt.lat)||!Double.isFinite(pt.lon))continue;
   south=Math.min(south,pt.lat);north=Math.max(north,pt.lat);
   west=Math.min(west,pt.lon);east=Math.max(east,pt.lon);
  }
  if(north<south)return;
  final double n=north,s=south,w=west,e=east;
  map.getController().setCenter(new GeoPoint((n+s)/2,(w+e)/2));
  map.getController().setZoom(Math.min(16.0,map.getMaxZoomLevel()));
  map.post(()->{
   if(map.getWidth()==0||map.getHeight()==0)return;
   // Add a minimum visible extent for tiny trips and avoid a singular bounding box.
   double spanLat=Math.max(.001,n-s),spanLon=Math.max(.001,e-w);
   if(spanLon>180){ // Date line: choose the route's first point, not the wrong hemisphere.
    map.getController().setCenter(new GeoPoint(pts.get(0).lat,pts.get(0).lon));
    map.getController().setZoom(11.0);
   }else{
    BoundingBox bounds=new BoundingBox(Math.min(90,(n+s)/2+spanLat*.65),
     Math.min(180,(w+e)/2+spanLon*.65),Math.max(-90,(n+s)/2-spanLat*.65),
     Math.max(-180,(w+e)/2-spanLon*.65));
    map.zoomToBoundingBox(bounds,false,(int)(24*c.getResources().getDisplayMetrics().density));
   }
  });
 }
}
