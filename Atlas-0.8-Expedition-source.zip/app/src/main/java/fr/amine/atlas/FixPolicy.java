package fr.amine.atlas;
/** Display-only selection: recording keeps its stricter 15 m / 5 s gate. */
public final class FixPolicy {
 public static boolean valid(long now,long time,float accuracy,double lat,double lon){long age=now-time;return age>=0&&age<=10000000000L&&Float.isFinite(accuracy)&&accuracy>0&&Double.isFinite(lat)&&Double.isFinite(lon)&&Math.abs(lat)<=90&&Math.abs(lon)<=180;}
 public static boolean prefer(long now,long oldTime,float oldAccuracy,long time,float accuracy){if(time<=oldTime)return false;long age=now-oldTime;return age>5000000000L||accuracy<=oldAccuracy*1.4f;}
}
