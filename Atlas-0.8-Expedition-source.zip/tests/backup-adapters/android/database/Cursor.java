package android.database;
import java.sql.*;
public class Cursor implements AutoCloseable {
 public static final int FIELD_TYPE_NULL=0,FIELD_TYPE_INTEGER=1,FIELD_TYPE_FLOAT=2;
 private final ResultSet r;public Cursor(ResultSet r){this.r=r;}
 public boolean moveToNext(){try{return r.next();}catch(Exception e){throw new RuntimeException(e);}}
 public boolean moveToFirst(){return moveToNext();}
 public Object value(int i){try{return r.getObject(i+1);}catch(Exception e){throw new RuntimeException(e);}}
 public int getType(int i){Object o=value(i);return o==null?0:o instanceof Float||o instanceof Double?2:o instanceof Number?1:3;}
 public long getLong(int i){return ((Number)value(i)).longValue();}public double getDouble(int i){return ((Number)value(i)).doubleValue();}public String getString(int i){return (String)value(i);}
 public void close(){try{r.getStatement().close();}catch(Exception e){throw new RuntimeException(e);}}
}
