package android.database.sqlite;
import android.database.Cursor;import android.content.ContentValues;import java.sql.*;import java.util.*;
public class SQLiteDatabase {
 public static final int CONFLICT_REPLACE=5;public final Connection connection;private boolean success;
 public SQLiteDatabase(){try{connection=DriverManager.getConnection("jdbc:sqlite::memory:");}catch(Exception e){throw new RuntimeException(e);}}
 public void exec(String s){try(Statement x=connection.createStatement()){x.execute(s);}catch(Exception e){throw new RuntimeException(e);}}
 public void beginTransaction(){try{connection.setAutoCommit(false);success=false;}catch(Exception e){throw new RuntimeException(e);}}
 public void setTransactionSuccessful(){success=true;}
 public void endTransaction(){try{if(success)connection.commit();else connection.rollback();connection.setAutoCommit(true);}catch(Exception e){throw new RuntimeException(e);}}
 public void delete(String table,String where,String[] args){try(PreparedStatement p=connection.prepareStatement("DELETE FROM "+table+(where==null?"":" WHERE "+where))){if(args!=null)for(int i=0;i<args.length;i++)p.setString(i+1,args[i]);p.executeUpdate();}catch(Exception e){throw new RuntimeException(e);}}
 public long insertWithOnConflict(String table,String hack,ContentValues v,int conflict){return insertOrThrow(table,hack,v);}
 public Cursor rawQuery(String query,String[] args){try{PreparedStatement p=connection.prepareStatement(query);if(args!=null)for(int i=0;i<args.length;i++)p.setString(i+1,args[i]);return new Cursor(p.executeQuery());}catch(Exception e){throw new RuntimeException(e);}}
 public Cursor query(String table,String[] columns,String selection,String[] args,String group,String having,String order){try{return new Cursor(connection.createStatement().executeQuery("SELECT "+String.join(",",columns)+" FROM "+table+" ORDER BY "+order));}catch(Exception e){throw new RuntimeException(e);}}
 public long insertOrThrow(String table,String hack,ContentValues v){String sql="INSERT INTO "+table+" ("+String.join(",",v.keySet())+") VALUES ("+String.join(",",Collections.nCopies(v.size(),"?"))+")";try(PreparedStatement p=connection.prepareStatement(sql)){int i=1;for(Object x:v.values())p.setObject(i++,x);p.executeUpdate();try(ResultSet result=connection.createStatement().executeQuery("SELECT last_insert_rowid()")){result.next();return result.getLong(1);}}catch(Exception e){throw new RuntimeException(e);}}
}
