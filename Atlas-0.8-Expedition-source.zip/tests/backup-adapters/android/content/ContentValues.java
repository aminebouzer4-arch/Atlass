package android.content;
public class ContentValues extends java.util.LinkedHashMap<String,Object>{public void putNull(String k){put(k,null);}public String getAsString(String k){return (String)get(k);}}
