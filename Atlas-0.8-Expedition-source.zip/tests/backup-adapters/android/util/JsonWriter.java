package android.util;
public class JsonWriter extends com.google.gson.stream.JsonWriter {public JsonWriter(java.io.Writer w){super(w);}}
