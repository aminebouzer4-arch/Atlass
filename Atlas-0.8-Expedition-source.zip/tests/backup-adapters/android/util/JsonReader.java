package android.util;
public class JsonReader extends com.google.gson.stream.JsonReader {public JsonReader(java.io.Reader r){super(r);}}
