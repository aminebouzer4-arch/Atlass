package android.util;
public final class JsonToken {public static final com.google.gson.stream.JsonToken NULL=com.google.gson.stream.JsonToken.NULL,END_DOCUMENT=com.google.gson.stream.JsonToken.END_DOCUMENT;}
