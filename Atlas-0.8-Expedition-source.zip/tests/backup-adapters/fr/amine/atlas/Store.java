package fr.amine.atlas;
import android.database.sqlite.SQLiteDatabase;
public class Store {
 public static class Trip {public long id,start,end,elapsed,anchor;public String mode,state;public double meters;}
 public static class P{public long trip,time;public int segment;public double lat,lon;public Double altitude,verticalAccuracy;public P(long t,int s,double la,double lo,long tm){trip=t;segment=s;lat=la;lon=lo;time=tm;}}
 public java.util.ArrayList<P> points(long id){return new java.util.ArrayList<>();}
 public void point(long trip,int segment,double lat,double lon,long time,float accuracy,double delta,Double altitude,Double verticalAccuracy){android.content.ContentValues v=new android.content.ContentValues();v.put("trip",trip);v.put("segment",segment);v.put("lat",lat);v.put("lon",lon);v.put("time",time);v.put("accuracy",accuracy);v.put("delta",delta);v.put("altitude",altitude);v.put("verticalAccuracy",verticalAccuracy);db.insertOrThrow("points",null,v);}
 public boolean hasActive;private final SQLiteDatabase db=new SQLiteDatabase();
 public Store(){db.exec("CREATE TABLE extras(id INTEGER PRIMARY KEY,kind TEXT,key TEXT,value TEXT,UNIQUE(kind,key))");db.exec("CREATE TABLE trips(id INTEGER PRIMARY KEY,start INTEGER,end INTEGER,mode TEXT,state TEXT,elapsed INTEGER,anchor INTEGER)");db.exec("CREATE TABLE points(id INTEGER PRIMARY KEY,trip INTEGER,segment INTEGER,lat REAL,lon REAL,time INTEGER,accuracy REAL,delta REAL,altitude REAL,verticalAccuracy REAL)");}
 public Object active(){return hasActive?new Object():null;}public SQLiteDatabase getReadableDatabase(){return db;}public SQLiteDatabase getWritableDatabase(){return db;}
}
