package android.content;public class SharedPreferences{String lang;public SharedPreferences(String l){lang=l;}public String getString(String k,String d){return lang;}}
