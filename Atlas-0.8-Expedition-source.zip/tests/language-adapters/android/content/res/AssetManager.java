package android.content.res;public class AssetManager{public java.io.InputStream open(String file)throws Exception{return new java.io.FileInputStream("atlas-070/app/src/main/assets/"+file);}}
