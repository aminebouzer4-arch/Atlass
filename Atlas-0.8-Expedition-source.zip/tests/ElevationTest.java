import fr.amine.atlas.*;
import java.util.*;
public class ElevationTest {
 static Store.P point(int seg,Double alt){Store.P p=new Store.P(1,seg,36,3,0);p.altitude=alt;p.verticalAccuracy=2.;return p;}
 public static void main(String[] args){ArrayList<Store.P> p=new ArrayList<>();for(int i=0;i<20;i++)p.add(point(0,null));if(Elevation.calculate(p).available())throw new AssertionError("missing heights");p.clear();for(int i=0;i<30;i++)p.add(point(0,100.+i%3));if(Elevation.calculate(p).up!=0)throw new AssertionError("flat noise");p.clear();for(int i=0;i<30;i++)p.add(point(0,100.+i*2));if(Elevation.calculate(p).up<40)throw new AssertionError("climb");p.clear();for(int i=0;i<15;i++)p.add(point(0,100.));for(int i=0;i<15;i++)p.add(point(1,300.));if(Elevation.calculate(p).up!=0)throw new AssertionError("segment discontinuity");System.out.println("4 elevation scenarios passed");}
}
