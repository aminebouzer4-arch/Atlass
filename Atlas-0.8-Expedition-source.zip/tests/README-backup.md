# Backup regression tests

These tests compile the actual Backup.java with thin test-only Android API adapters backed by SQLite JDBC and Gson. They are NOT Android instrumentation or device tests. The adapters are outside app/src and never included in the APK.

Dependencies: Gson 2.11.0, sqlite-jdbc 3.46.1.0, slf4j-api 2.0.13. Place those jars in a directory and use it for the classpath.

```bash
javac -cp '/path/to/jars/*' -d /tmp/atlas-backup-tests $(find tests/backup-adapters -name '*.java') app/src/main/java/fr/amine/atlas/Backup.java tests/BackupTest.java
java -cp '/path/to/jars/*:/tmp/atlas-backup-tests' BackupTest
```

Coverage: complete roundtrip, nullable old altitude data, segment retention; atomic rollback for truncation, incompatible version, invalid coordinates, orphan points, duplicate IDs, recording-state files and trailing junk; refusal to overwrite an active trip.

Still requires device validation: system file picker, process recreation, rendered UI at different font scales, map gestures, GPS recording.


## Tests 0.5
Dépendances supplémentaires de test uniquement : org.json 20240303 et KXml2 2.3.0. Compiler FeatureMathTest, GpxImportTest et BackupTest avec les sources Geo, Coverage, LongSet, Boundary, Terrain, Net, Extras, GpxImport et Backup ainsi que les adaptateurs. La sauvegarde exporte désormais le format v2 et le test couvre aussi la restauration d’un fichier v1.
