import fr.amine.atlas.*;import java.io.*;import java.nio.charset.StandardCharsets;
public class BackupTest {
 static byte[] snapshot(Store db)throws Exception{ByteArrayOutputStream o=new ByteArrayOutputStream();Backup.save(db,o);return o.toByteArray();}
 static void restore(Store db,String s)throws Exception{Backup.restore(db,new ByteArrayInputStream(s.getBytes(StandardCharsets.UTF_8)));}
 static void rejected(Store db,String json,byte[] original)throws Exception{try{restore(db,json);throw new AssertionError("Invalid backup accepted");}catch(IOException expected){}if(!java.util.Arrays.equals(snapshot(db),original))throw new AssertionError("Rollback lost existing data");}
 public static void main(String[] args)throws Exception{
 Store a=new Store();a.getWritableDatabase().exec("INSERT INTO trips VALUES(1,1000,5000,'Marche','finished',4000,5000)");a.getWritableDatabase().exec("INSERT INTO points VALUES(1,1,0,36.75,3.04,2000,5,0,NULL,NULL)");a.getWritableDatabase().exec("INSERT INTO points VALUES(2,1,1,36.751,3.041,4000,4,8,111,2)");
 a.getWritableDatabase().exec("INSERT INTO extras VALUES(1,'building','9999','2')");
 Extras.put(a,"kingdom","name","Test kingdom");Extras.put(a,"kingdom","color",""+(int)0xff007c83);Extras.put(a,"kingdom","emblem","Mountain");Extras.put(a,"kingdom","camp:9999","{\"lat\":36.75,\"lon\":3.04,\"trip\":1}");
 byte[] original=snapshot(a);String good=new String(original,StandardCharsets.UTF_8);Store b=new Store();restore(b,good);if(!java.util.Arrays.equals(original,snapshot(b)))throw new AssertionError("Roundtrip mismatch");
 rejected(a,good.substring(0,good.length()-5),original);rejected(a,good.replace("\"version\":2","\"version\":99"),original);rejected(a,good.replace("36.75,","91,"),original);rejected(a,good.replace("\"trip\":1","\"trip\":99"),original);rejected(a,good.replace("\"id\":2","\"id\":1"),original);rejected(a,good.replace("\"state\":\"finished\"","\"state\":\"recording\""),original);rejected(a,good+"junk",original);
 rejected(a,good.replace("\"value\":\"2\"","\"value\":\"99\""),original);
 a.hasActive=true;try{restore(a,good);throw new AssertionError("Active trip overwritten");}catch(IOException expected){}a.hasActive=false;if(!java.util.Arrays.equals(original,snapshot(a)))throw new AssertionError();
 String legacy=good.replace("\"version\":2","\"version\":1");legacy=legacy.substring(0,legacy.indexOf(",\"extras\":"))+"}";Store old=new Store();restore(old,legacy);if(snapshot(old).length<100)throw new AssertionError("legacy restore");
 System.out.println("Backup: roundtrip, legacy null altitude, segments, 8 invalid-file rollbacks, active-trip protection passed (SQLite JDBC / Gson adapters, not Android runtime).");
 }
}
