import fr.amine.atlas.Geo;
public class GeoTest {
 static void check(boolean b){if(!b)throw new AssertionError();}
 public static void main(String[] a){
 check(Geo.distance(0,0,0,0)==0);
 check(Math.abs(Geo.distance(0,0,0,1)-111195)<2);
 check(Geo.distance(0,179.999,0,-179.999)<230);
 check(!Geo.valid(91,0,5,0));check(!Geo.valid(0,0,Float.NaN,0));check(!Geo.valid(0,0,40,100));check(!Geo.valid(0,0,5,16000));check(Geo.valid(36.75,3.04,8,1000));
 check(Geo.jump(100,1000,"Course"));check(!Geo.jump(20,1000,"Vélo"));check(Geo.jump(5,0,"Marche"));
 check(!Geo.jump(72,2000,"Voiture"));check(Geo.jump(72,2000,"Vélo"));check(Geo.jump(180,2000,"Voiture"));check(Geo.jump(5,0,"Voiture"));
 check(!Geo.valid(36.75,3.04,16,1000));check(Geo.valid(36.75,3.04,15,5000));check(!Geo.valid(36.75,3.04,5,5001));check(!Geo.valid(36.75,3.04,5,-1));
 System.out.println("19 geometry / GPS-filter assertions passed");
 }
}
