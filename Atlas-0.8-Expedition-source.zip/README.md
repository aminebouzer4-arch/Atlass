# Atlas 0.8.0 Expedition — préversion du code source

**Refonte visuelle réelle du projet natif Android 0.7.1.** Ce ZIP est le **code source**, pas une APK installable. Il est configuré pour générer une APK via GitHub Actions depuis un téléphone. La compilation n'a pas été exécutée dans l'environnement de préparation (SDK Android indisponible), et le rendu exact devra être testé sur Android.

## Modifications Expedition

- Thème nuit unifié bleu anthracite, cartes dégradées, bordures discrètes, turquoise vif, boutons et typographie haut contraste.
- Carte principale avec assombrissement du fond exposé, brouillard **opaque ardoise texturé** et contrôles flottants plus sobres. Les rues restent entièrement masquées hors du territoire exploré.
- Barre de navigation inférieure plus compacte, surlignage de l'onglet actif et icônes turquoise.
- Carnet plus dense et sombre, mini-tracés turquoise ; carte géographique interactive dans la fiche de sortie et carte plein écran.
- Page Monde (progression, royaume, régions, téléchargement hors ligne) alignée sur le thème sombre.
- Paramètres et dialogues alignés sur les couleurs Expedition.
- Suppression de sorties terminées avec confirmation ; recalcul des zones découvertes selon les sorties restantes (fonctionnalité héritée de 0.7.1).
- Conservation des fonctions de suivi, permissions, sauvegarde et import GPX du projet 0.7.1.

## Ne pas perdre les explorations

Avant toute tentative d'installation, ouvrir Atlas 0.7 → Réglages → **Sauvegarder mes explorations**. Conserver ce fichier JSON. **Ne pas désinstaller l'app existante**. L'identifiant `fr.amine.atlas` et le certificat de développement existant sont conservés, avec `versionCode 13` supérieur à la version 0.7.0/0.7.1. Cette continuité ne garantit pas à elle seule qu'une installation réussira sur tout appareil : vérifier d'abord la signature de l'APK compilée.

## Compiler depuis un téléphone

1. Ouvrir github.com sur Chrome, créer un **dépôt privé** nommé `Atlas-Android` avec README.
2. Ouvrir **Code → Codespaces** et créer un espace de travail. Passer Chrome en version ordinateur si nécessaire.
3. Dans Codespaces, transférer **le ZIP**, puis ouvrir le terminal et exécuter les commandes ci-dessous (elles décompressent les fichiers dans le dépôt et publient un commit) :

```bash
unzip -o Atlas-0.8-Expedition-source.zip -d .
rm Atlas-0.8-Expedition-source.zip
chmod +x gradlew
git add .
git commit -m "Atlas 0.8 Expedition"
git push
```

4. Dans le dépôt, ouvrir **Actions → Compiler Atlas APK**. Une compilation sur `main` démarre automatiquement (ou utiliser **Run workflow**).
5. Si elle réussit, ouvrir la compilation, télécharger **Atlas-0.8-Expedition-APK** dans les artefacts, extraire `app-debug.apk` et l'installer **comme mise à jour**, sans désinstaller Atlas 0.7.
6. Tester d'abord la carte, le carnet, la langue et les paramètres avant une nouvelle sortie longue. Si le build est en erreur, copier les logs de GitHub Actions pour diagnostic.

GitHub Codespaces et Actions peuvent être soumis à des quotas ou facturation selon les comptes. **Attention : ne pas publier le dossier `dev-signing/` dans un dépôt public** : il contient une clé de signature de développement. Utiliser uniquement un dépôt privé.

## Fonctionnalités en cours de perfectionnement

Le style vise Expedition mais les cartes reposent encore sur les fonds raster OpenStreetMap/OpenTopoMap existants, assombris par un voile. Ce n'est pas encore une carte vectorielle nocturne native, ni une transcription pixel-par-pixel des maquettes. L'app ne dispose pas encore d'un bouton jour/nuit ni d'une nouvelle iconographie exhaustive.

---

# Atlas 0.7.0-alpha — carte et royaumes

- Nouvelle barre de carte compacte, détails dépliables au toucher ou par glissement sur son en-tête. Départ/activité au repos, distance/durée/pause pendant la sortie. Vecteurs pour localisation, suivi, couches et plein écran.
- Suivi GPS explicite ; un déplacement manuel le suspend. Recentrage ponctuel indépendant. Choix des positions fondé sur âge et précision ; ancien point grisé après 5 secondes, supprimé après 10 secondes. Filtre d’enregistrement conservé à 15 m / 5 s, trois mesures initiales. Reprise de positions récentes du téléphone et notification périodique.
- Palette blanc cassé, bleu profond et océan. Animation dorée brève sur un nouveau secteur de 30 m ; aucun effet ne dévoile le terrain hors de la bande. Cache du brouillard corrigé pour les changements de décalage de la carte.
- Royaume : nom/couleur/emblème ; provinces de jeu d’environ 1 km² avec surfaces estimées réellement révélées. Vue en tuiles, liste et accès à la carte réelle. Camps placés sur des points visités, liste des sorties associées, tour à 5 % actifs et 2 sorties, citadelle à 15 % et 5 sorties. Anciens bâtiments conservés. Trois expéditions permanentes, sans expiration.
- La voiture dévoile la carte et compte dans la surface totale. Elle ne compte pas pour les seuils d’évolution et expéditions actives. Les imports GPX selon leur activité sont inclus.
- Recherche Alger : le résultat ville est un point, la wilaya une relation MultiPolygon (réponse vérifiée le 20 octobre 2026). Recherche de secours sans filtre strict, type administratif clairement affiché et sélection explicite. Les résultats vides ne sont plus mis en cache ; anciens caches ignorés par une nouvelle clé.
- Sauvegardes : validation et restauration de la couleur, de l’emblème et des coordonnées/trajet du camp ; anciens fichiers conservés compatibles.
- Langues FR/EN/AR/ES maintenues pour les nouveaux écrans.

Validation : compilation Android et signature, 23 scénarios GPS/recherche Alger/royaume, 15 scénarios géométriques, aller-retour sauvegarde avec nouveaux attributs, fichiers invalides et rollback. Les tests hôtes ne remplacent pas un téléphone : rendu, ergonomie tactile, suivi réel écran éteint et autonomie restent à vérifier sur Android. Aucun pourcentage de ville n’est substitué silencieusement par celui d’une wilaya.

Identifiant fr.amine.atlas ; versionCode 11 ; même clé de développement. Installer par-dessus pour conserver les données.

# Atlas 0.6.2-alpha

- Choix de langue dans Réglages → Langue : français, anglais, arabe, espagnol. Préférence persistante ; orientation RTL en arabe. Les identifiants stockés des activités et des régions restent inchangés. Noms de lieux et noms de royaumes personnalisés conservés.
- Bouton ⛶ en haut de la carte : plein écran immersif, masquant en-tête, panneau de départ/activité et barre de navigation. Bouton ↙ ou Retour pour quitter. Le suivi continue pendant le plein écran.
- Carte principale : ligne de la sortie active uniquement. Finir une sortie retire sa ligne, sans supprimer les points, le carnet, le GPX ou les zones dévoilées.
- Palette bleu océan, surfaces claires, actions principales à texte blanc. Brouillard gris opaque et rayon de révélation de 30 m conservés.
- versionCode 10 ; même identifiant et certificat de développement.

Vérification : compilation, ressources osmdroid, signature et contenu du catalogue des quatre langues. Aucun test sur téléphone ou émulateur dans cet environnement. Les erreurs techniques remontées par les services externes ou certains moteurs internes peuvent conserver leur texte d’origine. Les toponymes cartographiques restent ceux du fournisseur de carte.

# Atlas 0.6.1-alpha

Mise à jour Android : fr.amine.atlas, versionCode 9, même clé de développement que les versions précédentes. Installer par-dessus sans désinstaller pour conserver les données, si la version installée utilise la même signature.

Nouveau : turquoise et menthe, panneau compact, recentrage dans la zone visible, brouillard gris nuageux opaque, corridor de 30 m de chaque côté. Les anciennes traces bénéficient aussi du rayon de 30 m.

Validation : compilation Android SDK 35, liaison des ressources osmdroid et signature APK vérifiées. Test hôte de la texture (262144 pixels gris opaques), surface d’un corridor de 60 m, passages répétés et séparation des segments. Pas de test sur téléphone ni émulateur dans cet environnement : recentrage réel, autorisations, rendu et autonomie restent à vérifier sur Android.

# Atlas — alpha Android 0.2.1

Première base native personnelle pour Amine. **Ce n’est pas encore le jeu complet.**

## Inclus
- Marche, course, vélo : démarrer, pause, reprise, terminer.
- Enregistrement GPS dans un service Android au premier plan avec notification.
- Stockage SQLite local de chaque point accepté ; les points déjà écrits restent après une interruption.
- Réouverture : sortie interrompue à reprendre ou terminer, sans reprise GPS silencieuse.
- Distance, durée active estimée, allure moyenne ; historique.
- Fond OpenStreetMap et brouillard visuel révélé sur 25 mètres de rayon.
- Affichage cumulatif des parcours ; bouton pour masquer le brouillard et recentrer.
- Export GPX par sortie terminée, segments distincts après pause ou interruption.

## Installer sur Android
1. Télécharger `Atlas-0.2.1-alpha.apk` sur le téléphone (Android 8 ou plus).
2. Ouvrir le fichier. Si Android le demande, autoriser ponctuellement cette application de téléchargement à installer des applications. Il s’agit d’une build de test signée avec une clé de développement.
3. Ouvrir Atlas ; choisir Marche, Course ou Vélo ; appuyer sur Démarrer dehors.
4. Autoriser la position **précise**, pendant l’utilisation, et les notifications si proposées.
5. Attendre que le GPS indique une précision. Marcher quelques minutes, éteindre l’écran, puis revenir dans l’application.
6. Terminer la sortie ; dans Carnet, exporter le GPX vers un dossier choisi.

Ne pas désinstaller pour mettre à jour : les sorties sont locales et une désinstallation les efface. L’export GPX protège les traces, mais l’import/restauration dans Atlas n’est pas encore implémenté. Ne pas utiliser cette alpha comme seul enregistrement d’une sortie importante.

## Test terrain court (15 minutes)
- Noter modèle, version Android et batterie au départ.
- Démarrer dehors, attendre un premier point, marcher 3 minutes écran allumé.
- Continuer 5 minutes écran éteint ; vérifier au retour que le tracé s’est poursuivi.
- Pause 1 minute : vérifier que durée/distance n’augmentent pas.
- Reprendre et changer de direction ; terminer.
- Fermer/réouvrir : vérifier le carnet et le brouillard.
- Exporter le GPX et vérifier qu’il contient plusieurs segments autour de la pause.
- Test séparé : pendant une sortie, arrêter l’application depuis Android ; réouvrir. La sortie doit être marquée interrompue, sans pont artificiel lors de la reprise.
- Relever trous, points erronés, batterie et éventuel message Android. Une mesure de batterie courte reste très approximative.

## Limites connues
- Aucun test sur téléphone physique à la livraison ; compilation et simulation ne prouvent pas le fonctionnement GPS terrain.
- Première interface fonctionnelle, pas le design final.
- Le fond de carte demande Internet ; cache automatique limité aux tuiles déjà vues, pas de téléchargement de zones hors ligne.
- La carte démarre à Alger puis se centre sur une position récente via Me localiser. Une position de prévisualisation ne dévoile jamais de terrain.
- Pas encore de royaume jouable, hexagones, pourcentages administratifs, auto-pause, import GPX, missions photo, lieux notés ou multijoueur.
- Filtre GPS expérimental : précision ≤30 m, ancienneté ≤15 s, seuil de déplacement 5–10 m. Peut sous-estimer les virages ou la marche lente et n’élimine pas toute dérive.
- Coupure >30 s entre points acceptés : nouveau segment, sans distance inventée. Seuil de vitesse 12 m/s à pied et 30 m/s à vélo ; ce n’est pas un système anti-triche.
- Durée basée sur l’horloge du téléphone ; ne pas modifier l’heure pendant une sortie. Après arrêt forcé, récupération de durée jusqu’au dernier point accepté.
- L’arrêt forcé Android interrompt le service : l’application ne contourne pas ce choix. Certains fabricants peuvent également arrêter le GPS.
- Affichage et lecture des points encore simples, à optimiser avant des mois d’historique.
- Brouillard visuel distinct d’une future mesure de surface : aucun pourcentage inventé.

## Données et dépendances
Pas de compte, analytics, publicité ou serveur de parcours. GPS stocké localement. Le fond de carte contacte les serveurs OpenStreetMap, qui voient l’IP et les tuiles demandées. Les GPX exportés contiennent les coordonnées et dates : partage au choix de l’utilisateur.

osmdroid 6.1.20 (Apache-2.0), Android SDK, AGP 8.7.3, Gradle 8.9, JDK 17. Stack épinglée pour cette alpha, à réévaluer avant publication. © OpenStreetMap contributors ; attribution dans l’application. Usage de tuiles interactif seulement, sans téléchargement massif. Source : https://operations.osmfoundation.org/policies/tiles/
Documentation du suivi : https://developer.android.com/develop/background-work/services/fgs/service-types

## Compiler
Ouvrir ce dossier dans Android Studio, installer SDK Platform 35 et Build Tools 35.0.0, choisir JDK 17 et laisser Gradle synchroniser. Ou, avec ANDROID_HOME configuré :

```sh
./gradlew assembleDebug
```

APK : `app/build/outputs/apk/debug/app-debug.apk`.
Cible Android 34 pour tests personnels uniquement ; exigences de publication Play Store à revoir avant distribution publique. La clé de développement est fournie dans `dev-signing/atlas-debug.jks` (mot de passe de test : android) afin de préserver les mises à jour sans désinstallation. Ne pas utiliser cette clé pour une publication commerciale ; garder ce projet privé.

## Vérifications
`tests/GeoTest.java` : 11 assertions indépendantes sur distances, antiméridien, précision GPS, ancienneté et sauts aberrants. Exécution :

```sh
mkdir -p /tmp/atlas-tests
javac -d /tmp/atlas-tests app/src/main/java/fr/amine/atlas/Geo.java tests/GeoTest.java
java -cp /tmp/atlas-tests GeoTest
```

## Étapes suivantes
1. Test terrain et correction de la fiabilité GPS et de l’interface.
2. Définition des cellules, calcul d’exploration unique et sauvegarde/restauration complète.
3. Campement, tour, monument ; progression sans pénalité de repos.
4. Limites géographiques et pourcentages sur zone pilote, puis extension.
5. Photos et lieux : reportés conformément au choix du projet.

## Validation de cette livraison
- Tous les fichiers Java compilés contre Android API 35 et osmdroid 6.1.20.
- 11 assertions géométrie/filtre GPS réussies. XML du manifeste et ressources valides.
- APK construit via aapt2, javac, D8, zipalign et apksigner ; signature v2/v3 vérifiée.
- Gradle Wrapper fourni ; build Gradle non validée dans cet environnement (résolution du plugin impossible).
- GPS réel et comportement batterie sur téléphone restent à tester. Voir CHANGELOG.md pour les vérifications propres à la version.

## Version 0.2 : correctifs demandés
- Brouillard entièrement opaque (alpha 255) : le fond ne transparaît plus. Aucun bouton de dévoilement global.
- Localisation indépendante de l’enregistrement, via GPS et réseau en premier plan ; état permission/GPS/recherche/précision visible, accès aux paramètres et recentrage sur une position fraîche.
- Fond OpenTopoMap par défaut (relief ombré + courbes de niveau, zoom maximal 17), fond Rues en repli manuel ; uniquement visible sur les passages dévoilés. Tuiles en ligne, sans garantie de disponibilité.
- Nouvelle interface : carte dominante, panneaux flottants, actions arrondies, navigation et carnet revus.
- Stockage altitude et précision verticale nullable ; migration v1 → v2 additive, sans suppression des anciens points.
- D+/D− estimés : précision verticale requise ≤10 m, médiane de 5 points et seuil de variation max(5 m, 1,5 × précision verticale). Affichage après 5 fenêtres exploitables. Réinitialisation entre segments et données manquantes. Pas une mesure altimétrique de référence.
- Profil GPS brut en carnet ; abscisse = progression des points, pas distance. Altitudes GPS ellipsoïdales, pas hauteurs au-dessus du niveau marin. Les différences de hauteur servent au D+ estimé ; pas de fausse altitude mer dans l’export GPX.
- Les anciennes traces sans altitude restent sans dénivelé. Pas de récupération inventée.
- Installer l’APK par-dessus la v0.1 : même paquet et même clé de développement ; versionCode 2.

### Essai ciblé 0.2
1. Sans permission : carte totalement masquée, carte de statut « Position non autorisée ».
2. Me localiser : autoriser la position précise ; attendre un signal dehors. La carte se centre mais reste masquée.
3. Commencer : les points enregistrés révèlent uniquement le couloir parcouru ; le fond Relief est visible dans ce couloir.
4. Vérifier pause/reprise, puis finir et contrôler le carnet.
5. Vérifier les anciens parcours après installation par-dessus la v0.1.
6. Sur une montée assez longue, relever D+ seulement si le téléphone fournit une précision verticale suffisante ; sinon le tiret est attendu.

## Correctif 0.2.1
Voir CHANGELOG.md pour le défaut d’assemblage corrigé. Ne pas réinstaller les APK 0.1/0.2.
Le script `tools/build-manual.sh` documente la compilation alternative ; `check-resource-linkage.py` vérifie les ressources de la bibliothèque avant assemblage DEX. Gradle effectue normalement cette intégration automatiquement.
Le diagnostic de crash reste local et est exportable depuis l’écran de secours ou Réglages. Il contient des détails techniques d’exception, pas un enregistrement GPS ajouté volontairement. Aucun envoi automatique.


### Version 0.3
GPS exigeant (1 Hz demandé, rayon Android <=15 m, âge <=5 s), stabilisation initiale, filtrage de stationnement quand vitesse fiable disponible. Davantage de consommation et possibles trous de signal. Nouveau thème nuit/ambre et position avec cercle d’incertitude. Aucun test terrain ou validation visuelle sur appareil effectué dans cet environnement.


### Version 0.4
Refonte de navigation, carte plein écran avec panneau compact et réductible, choix d’activité mémorisé, guide, fiches de sorties, réglages structurés. Sauvegarde des sorties/points en JSON via sélecteur système ; restauration atomique avec remplacement explicite. Terminer toute sortie avant sauvegarde/restauration. Le cache de carte, préférences et diagnostics ne font pas partie de cette sauvegarde. Tests de sauvegarde documentés dans tests/README-backup.md. Pas de validation Android sur appareil ou émulateur ; aucun gain GPS supplémentaire par rapport à 0.3 n’est annoncé.


### Version 0.5 : utilisation
- **Monde / Progression** : calcul dédupliqué, ajout de frontières via recherche manuelle, import GPX. Actualiser si une sortie enregistre toujours. Les valeurs sont approximatives, grille 4 m et échantillonnage du corridor tous les 5 m. Le dénominateur mondial inclut les océans. Le territoire administratif inclut toutes les surfaces de son polygone OSM, pas uniquement les lieux accessibles.
- **Carnet / fiche** : correction du terrain après confirmation d’envoi des coordonnées à Open-Meteo, puis rouvrir la fiche pour le profil. DEM approximatif, ponts et tunnels non représentés. Pas de durée inventée pour les GPX sans heures.
- **Monde / Royaume** : nom, ressources (1 / 1 000 m²), camps puis tours puis citadelles, coûts cumulés 5/20/60. Tous les modes et imports participent. Territoires de jeu et surface géographique distincts.
- **Monde / Hors ligne** : secteur autour du centre choisi sur la carte, téléchargement explicite, puis activation. Les petits secteurs sont des cartes vectorielles simplifiées OSM ; pas de cartes topographiques complètes, pas de routage.
- Sauvegarde JSON v2 garde les nouvelles données sauf les secteurs hors ligne et préférences. Restauration v1 conservée.
- Limites alpha : 25 Mo / 200 000 points par GPX, 4 millions de cellules de couverture, 5 000 échantillons d’altitude, cinq secteurs hors ligne. Requêtes externes bornées, un seul traitement mutateur à la fois. Les services publics ne garantissent pas leur disponibilité.

### Validation 0.5
Tests JVM des sources de calcul, import et sauvegarde avec adaptateurs SQLite JDBC/Gson/KXml2/org.json : 15 scénarios de mathématiques (surfaces, doublons, trous, antiméridien, altitudes, échantillonnage, table primitive), scénarios GPX et restauration/rollback. Vérification réelle de réponses Open-Meteo, Nominatim et Overpass sur des coordonnées publiques de test. Compilation Android et signature contrôlées. **Aucun test visuel ou d’exécution de l’APK sur appareil Android : ces tests restent nécessaires.**
