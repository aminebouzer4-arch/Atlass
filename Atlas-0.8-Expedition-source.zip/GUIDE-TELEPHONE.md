# Installer Atlas 0.7.1 depuis un téléphone Android uniquement

Ce ZIP contient le projet Android **source**, PAS un APK déjà compilé.

## Avant tout
Dans Atlas 0.7 déjà installé : **Réglages → Sauvegarder mes explorations**, puis conserver le fichier JSON à part. **Ne désinstalle pas l'application** : cela effacerait ses données locales.

## Compiler gratuitement sur GitHub (uniquement via navigateur Android)
1. Connecte-toi à https://github.com puis crée un nouveau dépôt **Private** et coche « Add a README ».
2. Dans le dépôt : **Code → Codespaces → Create codespace on main**. Sur Chrome Android, le mode « Site pour ordinateur » peut aider à afficher l'éditeur.
3. Dans le Codespace, envoie le fichier `Atlas-0.7.1-Carnet-GitHub.zip` depuis ton téléphone, via l'explorateur de fichiers (Upload) de l'éditeur.
4. Ouvre **Terminal → New Terminal**, puis colle :

```sh
unzip -o Atlas-0.7.1-Carnet-GitHub.zip -d .
rm Atlas-0.7.1-Carnet-GitHub.zip
chmod +x gradlew
git add .
git -c user.name=Atlas -c user.email=atlas@users.noreply.github.com commit -m 'Atlas Carnet 0.7.1'
git push
```

5. Ouvre ton dépôt GitHub dans le navigateur → **Actions** → **Compiler Atlas APK** → lancement déclenché par le push. Patiente jusqu'à la coche verte. En cas d'erreur, ne tente pas d'installer un fichier incomplet.
6. Ouvre le job terminé → **Artifacts** → **Atlas-0.7.1-Carnet-APK** → télécharge le ZIP d'artefact, décompresse-le dans « Fichiers » sur Android, puis touche `app-debug.apk` pour installer.
7. Android peut demander d'autoriser temporairement l'installation via ton navigateur ou gestionnaire de fichiers. Vérifie que le nom affiché est « Atlas ». Installe **par-dessus** Atlas 0.7 sans le désinstaller.

La clé de signature est celle du projet alpha original et est présente dans le ZIP : elle permet les mises à jour sur le même téléphone si l'APK installée utilise bien cette clé. Ce n'est pas une clé commerciale. Le dépôt GitHub doit rester **privé**. Les Codespaces et Actions ont des quotas gratuits susceptibles de varier.

## Tester la correction
- Carnet → ouvrir une ancienne sortie → la carte doit montrer rues/relief et tracé. Bouton « Voir le parcours sur la carte » : zoom et déplacement.
- Fermer et ouvrir « Explorer » : aucun ancien tracé affiché sur la carte principale.
- Réglages → Sauvegarder mes explorations, avant toute suppression.
- Carnet → fiche d'une **sortie terminée** → Supprimer → Annuler : aucun changement.
- Revenir, Supprimer → Confirmer : fiche supprimée, surface recalculée, autres sorties conservées.
- Vérifier le royaume, la carte et le carnet, puis relancer l'application.

*Remarque* : une carte OpenTopoMap ou OpenStreetMap a besoin d'Internet et d'un cache de tuiles, sauf si des données hors ligne pertinentes sont déjà disponibles.
